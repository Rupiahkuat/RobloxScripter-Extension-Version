// RobloxScripter v4 - content script
// Watches AI replies -> detects command blocks -> local server -> Studio -> result goes back to the chat.
// v4: 32 tools, tool catalog + quick templates, new UI (tabs, cards, drag, FAB, toast, accent colors).
(() => {
	if (window.__rsLoaded) return;
	window.__rsLoaded = true;

	const FENCE = "`".repeat(3);
	const LOGO = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAZQklEQVR42u2deZRc1X3nP79733u19Fbd6m61UGMNQkYCtKEFIbOImIPNnDkzSWY8OZyYLbFn8RaQ4kwydmzAGOKMQYDt5JyEMVgLy7AF8GQwdmaMgzH7YoTQhlglIfVW1V1d63vv3vnjvWq1Gi3d6pKA0PecktTVpap63+9v//3uuzJnzmzGuRQgQBj/nAaWAp8FlgOzgFPi1/xLXhbYDrwNPAc8BrwAFOPf6/g1ZjxvJuMkQI8C/nTgMuBzwGymFsAbwP3AemDzQTA7agJkFOvzgTXAJYA76jVh/Dr5GEj/aC2oPfSo531gI7AWeHUMfgeX7La21sNJfU2NrgE2AMvi54NRgKuPGfiMufYawGEsmGcAXwQc4PExZumgdv1wJmca8DPgasCLgbfxm8uU5TmAECfGJoixujrGblqMpR4vATXwlwNPxU52CvijI+KzMYbLD0WCOsjPYWxqHgM+Gb/RFPBHR0QQY/hYjGk4FnM15j/ZWGXuBVpHgT+1jm7VSGiNMZ0WYywHI6D273uAk6bArzsJJ8XYHoB7LQqq2f2rgT+eAr/uS8WYzok14Je1yEjmzJmt4idPATbFv/i4hZXHM3cIgQVxNi0qZscC34jjWDMF/jFzzCbG+Bsx5qqmGvOAi+MX6CmsjtmqJbcXx5gHNWfwhTh5mJL+46MFXow5iqiq+R+PkBlPrfo6ZGLM0yrO0rprNmkKn+NCgI0xX66ACzmw8Da1jv2q+doLVZwiM2X7j7svAFim4uRgioAPhoA5Cjh5ioAPjICTP9pOV330Ywb1kQa/XAJjpgg4/vmkgx3K4S1bie7swvo+iEwRcFyW4yDZPjj3M/R+9+8xykGsmdKA4wU+2QE4+wL2fv828k4CquWPtC84dt9c5MBHXSR/ADn7d3jvxtsp6BS6UgZ9DGuHx2HYxqk76EphjYEwjL63tfEAh540+Kw8nz033k7RTaP8EKNiZOyxyFXHvKmS6GHja/rQEaAUBAEylEMlU0hDI1ZprNJgDbZUnJTZsWedx97v1yS/inE9rOvG5qf+DEjSjTXXIhYo+diCj01o8PT7CfpACVAKSkVUc4bKH/4nCmdfgN8xA2ssYTJN8xtbaPr6FZiJ6rLjQG4AWXEe7910B8NeA6paBWuxCUV6by+SH8Rop35WQgmq5FO5bAmDSztQ5QClLSpbIfFqP8nH38L2DEPKrQsJTl3AL5dQJ82h/3t/R3bOPExtisgYcBXu3t00GRup8ETMTm4Ae+a57L35Jwx7jahqFbEQplJkdr9L+59/ATM4iKRS9c0HLFRTmlJHElX0QQy2LYHMbSV94Sxab30eNu2D9ORJmKQTFqwxaM8j++1b6Z87D7IFdL4AgQFHQRokmZyYmYgl3y5Zyd4bbyfvNaCr1Wg0uyFJpnc306+6BLP9NUilDw/+0TrSpEaSGnEEa0GVQlTep9Csyf3nxajWdHSN8kFqgFbIUI7gM79LbsFiVH8JEglwHFre3IH7zuvYZIKGd9/EjvebOg6Sy8KST7F37TqGk83ochUrYNJJWgb20rn6UsKd26C5BYLg8EFBaFAWrLVYVx1ZDixYJSS2DZAJDVRDgq40pZObsL5B532K0xM0fqob95Ft2CZvUk550iZIGUNxwTJCsYgJsckUnY/+Ay3fXYOpVCJ7rRQ2kRy35LNkJXtvWUc+1YIuV6KgJJkk07uHzqsuxWzfDM2Zw4OvBPwQcTWFNStIPLUb/bOd2EwCwsMAZi3W07iPbMENLaIEEaH0B6fS//snQznEWkvllFY8LZN2/5MiwFoQpTHtXVgriGhc35B+YB1BoYDNtCEmHpE/ko12HBjMImesZN/N68inW9DlKgiEySSZnl10rr4Us+O1I4MvAtUQpRVDq88kd+Y0vLktdJRC1BNvYZuPQAJgEw4IWAHKAYlfvIV7/olUk1Eoapo9cPSkQ1I1aW+lBNxEpLpa4ZQr6PwQNpFAwjACfhzgy2AWWbCUvTevY6gxMyL5YSpJpv+9CYBPZHbSHvk/X0lu8TR0bxkfS99XFmHOmYUMVUHLkaXLRA/rKCQwuKUAHAFrEUchSiadEtQnExY7InmCRYwZv2TEks/8Jey9eT35hgy6VAGEMJ2gJdsTmZ0dW44M/gHvqzBNHhjBopDQUA1Cer+8CHPuOEkYfXlxQikjP6u6ZB91IcC+r9QwMfDV/CXsu2UD+eb2SPIthKlR4G/ddGSHO/qjtcIMlmi57kkyrw9iGj1saJHQ4hPS97WFmPM+gQyOjwQ7SrtszS7VKfGoXy1IjvjEocH/wQaGMh3ocnnE7LT07mH61z6P3fwytESSb42J8g6t46G+w5iPhIMpVGj+66dp2ZLDpt0oq0WomIDery2KSJiIJiCj2LAfHgLkoP+2RwA/hzptMft+sJHBTEck+UoRphI0979H5+rLMFteGQEfwGloQBWHkdwAVEqR5mkdkTJWC81+ElrWPkPLzjymxcMaEKOphiF9X1qEOevE8ZNgoz+sGOyHiYAJlxcGc6hTF7Dvlg0MNreji7HNTyVoGuxj+prLsVs3ReCHIQQ+0tZO9raHyd60Dv/iLyKzP4kT+KjcABSGI+3QOtYOeT8JNz5L8xt5TJMDoUVVoWoMfV9djDmre5wk2BHgpU4NoLrUguyEwV/Ivls3MNg6HV0sYxWYVILmoX6mr74M+9pv90u+1lAuEy5YSt+pJ2NmnczApz+Dly+R3rGZ9LP/TOLZJ9A7XouyZxFsMoV1vQikGglDZTI3PA3//SyGZjUiw35kjpyQvisX065B/XoXtsU7aIgqUgsyJApN61SlrvseAHuo6CcGX5+6MDY709GlEiCYRIKmbG8k+ZtegJbWAxyuwlJcdg42sDjDJYzSlByP0sJlDCxZhnfFatK73yT18tMkn/olzqYXYN8ebBBgvQR4CUjGJFz/NLLmTAbnNiLFELGWqrb0rT6DdgvqN7uwzQchoTZcLvUtvk6KALFgtUOQasDGY702DLFBgMioMnEN/NMW0vPDu8hlOiKzI0KYSNA0sI+uNZdjN780BnzBBgFk2igtWIYtC9aJy8Q2RBUDxBiq2qFy4mxyc2bj/N4fkty7l/SWl0m/+CTuC09hd70dmaiEgxku03LTM9ivr2Dw1GZUKQBjqUqsCSGoZ97dn6zZ+OMCgw1CEA+xiiChMU4U3k5GFdTkpN0g6Qb8rm7wLWgHd7AfBgci02FtBP5QDjX3NPbdsoFsaw38KMNtHuyj60+viKOdAyUfJUilhJkzj+Ks2VDd33xXNjIJVmtEQFeqqGyJcLjMcFsnPRdcxNt/eR3ZH96Das5ERFpGfEJm7bO0vDWMaXIRoxBfqBpL/1fPwC4f4xOUQCVAZ6vxdYUEbR40JaIk87gTIBLZ2MEs4YIllD4xC12tQEKR2vpKVM9xnP2Sf8rp9NxyJ7nWLvRwOQI/laCpMMD0P70c++qLB0Q7oz9H+T7+medRbXCiskacFFmlMV5cCAuC6DntgNaoIEANFjH5ELvtNWzPe4jr7s9uEw4mXyZzwzNkduYxKQ2hRftCRRv61izBrpiJDFYiEkSw1ZDEjhwkNOIbghaPYGEHMuyDVkfddlVHAz7VCrq/F/XJUxn48l/iBwYrkFDQ8H/ujRovjgtDOfS8+ey7dSO59hNim28JPY+moX661lyB/e3z75f8moYZA8kUpeXnYUNQIiMZdrIwTKZvL05TAtOSwmhnxORZEawotKdpeO5X2MqYxv2IYy7Rcv0ztGzNY5Maay3KQFUZ+lcvxq6INUEJ1lN4z+wiUQywrsZWQoZ+/5OwYDpqsAKV4Kg0Qbe1tV4z4ebLGWeS/7Nr6Pvif2O46xNQ9ZH2JCdsvAP3ntswzRkk24eeO5/ev7mbXOcMdKGMFYVJJ2nK9dF11aXY3z4HmYODjwhSrSDds+j/4zX4OGgLmBDbkKDzkbuZ9mdX0PDaKzT07COYcSJ+QxqxUbJllSJhLK3/8yZsXw/UNGC0U3U1tlgl9dxeOL2T0onpqIJqIHCF6oouGt4chjey0JRA9hXwqpby2TMJyz6BJ1Q+1Q0LZ+D6wNu5qEB3zDRABKlUqM5dwL7f+7eUGlsQ65MIy3R//3q8W64hTDcipQJqyQreu2UjAy2dqOEKOBqb0DT17KZrzWXYV186pOTXyJZKGX/hckqtUSsyKsEIjkDixacIhoaQXz5K01//BQ29e7DJuENlDNZzSb39BuqNbVEp/GAFwZomFKu03PQszdsGMCmwYlFVQ8WE9F21BM6bBUUf2+jiPLqT9htfIDlQBaWpuoqBc7qonDoN8SfuD47CBIEJQyiAVKvgaNziMMnnfo0tlRDHBd/Hzuim2jkDKVdGYjfraLyhLPqdN6Lw8HDtPBslO6UVq0ZFfxbjeaT39eI+/XjUlHc9gkVnUpy3AKmEI1MZ4kLqpd9gB3OI4xw+iXEUDJRweipIbf+ECCoUgmYPO70BiVuq1hrczT24uTLW1VEUVPQx/tE544kRYMFqjZftp7m3B9WUxlYNw63TeffHP8X+u4uRwYHIof70fmZ+80uk0h7Gi9RSFSv0z5vPwI/uxmlsxJaLB5/rEYHAh/ZOSguXY8tgYxsuxuAbQ+Vf/wfklNNxh7IEc0+nnHYRP9ImqwQ3gMQzv8LKYbpgtY5ZYCmsPpPcp2YghTCqoApIS4JpP96Mun8LtsGFQhVO66T3f6xi+JTmSLjSmlQ+IJGrHJUjljlzZtuJx/8WSSQJzr+IfV/9FiUviXE9mvHpuuLfEL6+DWlsRPp7sf/+EvZcczOlcogKQ2xoMc0pOl97mdarLiXIZZFUOio5jPY1w3nsyvN590d3E5SCkeaImCgCkrQmWarSsOk5qo0Zhk6ehwRRlGQcl+aBHrr+6CLCXDbSgLEJoggYgwqheOVSsud0YXM+oqLwWqU82jdsw314W5SY+QbV4JH9q/MotHlIMUAjtN33Ot4T72ArwUiGfMzDUCtCWK3g3Pn3TP/bG1BNKZRfYbgxSel3P4+ulsEYTGs78uBGZnzrSpIajFKIUqh8iZ4Fi8nesgGnORPNDI3WBBFUGFBZtAJfGST0o0pmnOyJCWGoTBFN7/KzGTr5dFTVRObDGEgK6S0vw+jw82DgB5biV5YycO4MGPJRjsIqUEmP9tu34D1c6/mClAKqK7spTU+hCwE0JWh99B28+1/DVPyjAn9SiZgoRdjeifurR2nYuw+bSGELhuKC5dDcgg1DJAywre2oh+9i5ndWk/AcQq0QrVGDZXrmL2bg1o04La3YUmmEBBuGSEMj1VWfxTZowlQ6wjAM9ic+WqPDEJ0vRw5axWUQG4Xuyed/HSVfY83CCPhQ+K9LGDinC8lVo0qshOiUS/u6rbj/uCNu6MTFN0dRndeOqRiMFtyCj/ubd6LX6KPPZ4/+fxqDKIXND+Hsfiu66iCk0jEDWtqQ2sWHAaatHXn4brqvW00y6RDWNGGwRO+CxWRvXofb3DxCglgw2qH5b2+g++9uo23LyySshdYUpikZJVxhiA3D/bOnFgSL1ZpEvoz78tORox8t/aMl/0tLyK6aCflKXOYx6JRH+/qteP97e2R2akFCHC35nSkIDVYJeqCCZONEzXxAUxFWBPF9vMFcbBoMJJJIKhVFIrXrDgJMazvqwY10i2LXt9dSLlu0KNRgkZ75S2DtOlrXXEEwlENS6Uh6n/gn0o//jHRjM2b2XPwV51JasYrCnNOpZDLRNvMKSLWCqlXLUilSm19Fvfk6QSIZfacxkl/8ylIGVk1HBksgCoPBcT3a79iK+/C2AyR/pMHjavBUlHGL4AwHiB9iRCZVFa1DNTQaR4m+hcQZp7yvdChhTMID6+m2ll3fuolyxaKNRg0V6Fm8DPnhRjJ/cglBbdqtsQkjEpmkra/gvfIcyfV/Q2bGifgLllFZ+TsUF6+gdEI3VQdsGUhC6sUnsYU8kmmLnHsNfN9S+PIysqtmwHAZHMFYi04kaF+/Been298P/ugcSO2/TBldHf3QlKOPUKodIeHBDXQbw66rb6ZcCdHioPNl9i1ajL11I61/cgnBUExCbco6lcamGwiMRfbuwXn7Xtx/vJfG9umE8xZQWXo2hTPPJTh9PsmXnopKE3as2VnKwKouZKiCOEJoLU7ao/0nW3EPBb4wUuk9QOg+DOXoA2yrjE8gJPYJ6qE76VbCrqtvoVwN0caiBsr0nLYYbvoJbWsux88P7g9RY1MiAJ6HTSaxlkjSn/x/pP/556SbmpGTTsHseRebTAFmP/hfXUr/qi5ksIwohTEGpzFBx4btuI9sO7Tkj+k111yK/VA15SfYIar5BHlwI93fWUMqqQklmkBTQ0V6Fi5j4NZ174uODrDJYQgmRLQTmapMGyFCsHUTtlyKajJhZHaK/2UJA+fPgHwF0ZHNVymP9vXbcR/YOj7wR9piIfBh6wmPFodxslAzR/LAemZes4akK4QioBVquETPGcvI/uhOnOaWCNBD7YSxUe2nZqoklY78kB9GNv9LZ9B//gzIVlCiMGJR6QQdG3fgPjgB8Eesq6q1ij48BNhRtj9SUZkwCd3XXkXS0xitwInzhNMWkl17B05j08E14RDhMcaiXIfClUsZuPAEpOCDEoyxqJRHx13b8f5ha5RkTSCEFJEREqzUZzaovlMRcSJkJ1ATqfkEeehOur+7hmTKxWiFoFDZEj0Ll0cZc8tBMuZDmUNjIe3iz24BPxqwNQIqlaBjww68+ycm+SNTELKfBKmTG570/oCoI+XHEVDUbDGuF31Bx4nndvQ4fEJH5BOuXUPSVdENqZVCDZXoWbSU7K3rI3N0JE2Iq5tmoEjLdU/T+G6RoEGhGz067tmB9+AWwvGAX9sTFj8sRD1gIZqYDu3IROYHRoBI3LXKZUFF+UAl6eCftQo9OIDkBqJZ//zg+M3RfesjEhIOoZK4bFGiZ/4ZZNf+BGdUxnxYTUw62N5hMt97lszuCu0P7MS77zVMk4ccaW5VgJKP5KvIsI8eKBPObaOS8aBqEK2xxQAbhJOeD3Imb3UsyTe2oUSiVmA5YN8XVjOtaybOjs1YEdyhLPLE/x23OVIPbmCmwO5v3UylGkY3sRss0bNoOfKDjWSuvJRgMPf+KurYZkvKxfYXyFz9JKboEza4UV3/SOAHBhbNoNqRQnxD2NXE8AUzMRjEgBHB25PH+gYmuPmnLuXoA5rzfhXdOYP31v2cfGMTulLBiIJ0AtFg05DZtJOOSy7EjFNarOOgBvqwn7uMXd9eS6UUoKzFGoPNJOl86UUyV11CkM9H258Ou0VJsKFBxrs/TQmq4DP8F2eT/fQM1FAQhZzlAB0aQgWucui49inY2Q8JZ1J7BNQkxR9JJLHvvkXHD68lmVCEqVQkEoUiNlfE9vrYgf4JiclInnD/emZe93USKRejBFEKyZbYt2AJubXrcJqasZUjNEKsRbRM3LUVqpAtR38XfDCWwFWoRo/Wh3Yi2/sg6Ux6g8bEmvKHtLdJ1KYXadr8MqprJnR0QkMapV1o0KQKBVIP3TXBpo/BphtRL/yG5r4eip++iMA30WEFpSrDc/4V7qlnkPrFIxhbv9IAIohv8M8/iersFlRokITCsULqnQJt67fi/HwnNunUZUJuciZo7MTEcB7ledhZJxO2T8dqB+s4OOUivPLC0fGrHVS2D/O5y9n9zRspV4LoPsuOS9Iv8YnPX4B5b1c0flivHezGwqwMYVMimpIQUPkqak8eWw6waadu44n1K8YZA43NhNYgb+5A79iyv36iVLSd9GgkpFbAu39d5JivXku5HCAYVLEYRWH1vlWNEtg5gBPakRoXSqLedoNbt13y9a+GmrhymUhhk6MzYjupjdQjJNy3jm7XY/c3vkepGBw5nJzMSjgHFtxq25RMfT/z2Nwh3Zq6374hImEa6q7bOMH32fXNGzGuG3XBjgUPcVZ/rNdH6hb1EoaY1nb0vXdwguMy9PXvxDcDsXxU10fujICaOdL/63Y6gwpGawL56N7ysX5R0HH/5grKRRjPDvwP8fro3uvLmqOOrKYIqGfo+y+AgJ2jAq2pdZz0N/57pwJenyLgAyPgdQU8P0XAB0bA8wr4BQc54W1qHXPTHwK/UESHEu9i//kmU+sYhw4x1ruA5xTRSdD3jfrl1Dr2BBBjXqyZnR8DVfafbzK1jp3tVzHWP67ZIgfYSnTOYc02Ta1js2q+9p4Yc0eNskk3EB3JPaUFx1b6/RhrAUyNAAVsA66f0oJjLv3Xx1grwNROU60dTv84cDbRwT7BVGhat1U7nfafiM6br51eewDANe98MfAm+8/BnVr1Af/NGNsDok01xkYJ0A/8AZCdIqFu4GdjTPsZs41FHSRG1XF54rPAjlEkTDnmiTncGvg7Yiyf5yAnFqpDOAsdZ8griQ6kd2LmpogYH/ASY/ZYjOFzo+3+kQgYTUI/cBFwbZw8TBExPuCrMWYXxRjqQ0WWtSjoUG9au/H748BDQAqYT3QqtIwiq7bkYwS4HRXCy6gYfz3wR8C9o/A7ZIlH5syZPZ4PHM3g6cBlwOeA2VPCD8AbwP0x+JsPghmTJYBRTNfeNA0sjR3McmAWcMrHQAsssB14O7btjwEvEBU1a8BbxlnY/P9Njp5kbA305QAAAABJRU5ErkJggg==";

	// ------------------------------------------------------------------
	// CATALOG OF 32 TOOLS  (n=name, c=category, r=read-only, d=description, q=example request)
	// ------------------------------------------------------------------
	const CATS = {
		baca: { label: "Read", color: "#4C8DFF", icon: "◉" },
		ubah: { label: "Modify", color: "#A78BFA", icon: "✎" },
		script: { label: "Script", color: "#FFB020", icon: "{}" },
		ui: { label: "UI", color: "#F472B6", icon: "▣" },
		dunia: { label: "World", color: "#3DDC84", icon: "◍" },
		uji: { label: "Test", color: "#22D3EE", icon: "✓" },
	};
	const TOOLS = [
		{ n: "project_snapshot", c: "baca", r: 1, d: "Map of the whole game: structure, scripts + their functions, remotes", q: "Take a project snapshot first, then summarize my game's structure." },
		{ n: "list_children", c: "baca", r: 1, d: "Contents of an object (depth 1-4)", q: "Show the contents of Workspace 2 levels deep." },
		{ n: "find_instances", c: "baca", r: 1, d: "Find objects by class / name", q: "Find all Parts whose name contains 'Spawn'." },
		{ n: "get_properties", c: "baca", r: 1, d: "Read an object's properties", q: "Read the properties of the object I currently have selected in Studio." },
		{ n: "get_selection", c: "baca", r: 1, d: "Objects currently selected in Studio", q: "Show what I currently have selected in Studio." },
		{ n: "get_script_source", c: "baca", r: 1, d: "Read script source (optionally by line range)", q: "Read the relevant script and explain how it works." },
		{ n: "script_outline", c: "baca", r: 1, d: "Script outline: functions + line numbers, requires, TODOs", q: "Outline that large script first before editing it." },
		{ n: "search_scripts", c: "baca", r: 1, d: "Search text across all scripts", q: "Search all scripts for where RemoteEvents are used." },
		{ n: "search_toolbox", c: "baca", r: 1, d: "Search free Toolbox assets", q: "Search the Toolbox for a low-poly tree asset." },
		{ n: "get_output", c: "baca", r: 1, d: "Latest errors / warnings from Output", q: "Check the latest errors in the Studio Output and fix them." },
		{ n: "create_instance", c: "ubah", d: "Create a new object + properties", q: "Create a 100x1x100 Part floor in Workspace." },
		{ n: "set_properties", c: "ubah", d: "Change an object's properties", q: "Change the color and material of the object I selected." },
		{ n: "bulk_set_properties", c: "ubah", d: "Change properties of many objects at once (filter)", q: "Change every Part named 'Wall' to Brick material." },
		{ n: "move_instance", c: "ubah", d: "Move an object to another parent", q: "Move all enemy models into the Enemies folder." },
		{ n: "delete_instance", c: "ubah", d: "Delete an object (with review)", q: "Delete that old object, but show me its contents first." },
		{ n: "clone_instance", c: "ubah", d: "Duplicate an object N times with an offset", q: "Duplicate this Part 10 times in a row along the X axis." },
		{ n: "set_attributes", c: "ubah", d: "Set object attributes", q: "Give that sword the attributes Damage=25 and Cooldown=2." },
		{ n: "tag", c: "ubah", d: "Add / remove CollectionService tags", q: "Tag all NPCs with 'Enemy'." },
		{ n: "group_instances", c: "ubah", d: "Group objects into a Model / Folder", q: "Group those Parts into a single Model named House." },
		{ n: "arrange_instances", c: "ubah", d: "Arrange objects: grid / line / circle / align", q: "Arrange all children of the Chairs folder in a 5-column grid." },
		{ n: "create_tree", c: "ubah", d: "Build many nested objects at once", q: "Build a simple house (walls, roof, door) as a single Model." },
		{ n: "create_script", c: "script", d: "Create a Script / LocalScript / ModuleScript (syntax-checked)", q: "Create a full checkpoint system with comments." },
		{ n: "edit_script", c: "script", d: "Edit a script: full replace or find/replace", q: "Fix the bug in that script with a small edit." },
		{ n: "replace_in_scripts", c: "script", d: "Find/replace in ALL scripts (with dry-run)", q: "Replace every wait( with task.wait( across all scripts, dry-run first." },
		{ n: "run_luau", c: "script", d: "Run one-off Luau code in Studio", q: "Run one-off Luau code to count the number of Parts." },
		{ n: "create_gui", c: "ui", d: "Themed UI: corner, stroke, gradient, layout", q: "Build a modern dark-themed shop UI with 6 items." },
		{ n: "terrain", c: "dunia", d: "Terrain: block / ball / cylinder / hills / clear", q: "Create a 200x200 terrain hill, 25 high, Grass material." },
		{ n: "set_lighting", c: "dunia", d: "Lighting + Atmosphere, Sky, Bloom, etc.", q: "Set a dusk mood: lighting, atmosphere, and bloom." },
		{ n: "insert_asset", c: "dunia", d: "Insert a Toolbox asset (scripts removed by default)", q: "Find and insert a tree model from the Toolbox without scripts." },
		{ n: "scatter_instances", c: "dunia", d: "Scatter random objects, snapped to the ground (raycast)", q: "Scatter 40 random trees over a 200x200 area, snapped to the ground." },
		{ n: "verify", c: "uji", r: 1, d: "Audit: syntax, remotes, loops, Parts, dangerous patterns", q: "Audit my game: syntax, remotes without handlers, unanchored Parts." },
		{ n: "playtest", c: "uji", d: "Run the game briefly, report errors (experimental)", q: "Playtest for 15 seconds, then report all errors." },
	];
	const TOOL_BY = new Map(TOOLS.map((t) => [t.n, t]));
	const ALL_TOOLS = new Set(TOOLS.map((t) => t.n));
	const READ_TOOLS = new Set(TOOLS.filter((t) => t.r).map((t) => t.n));
	// tools whose results the AI MUST see (not only on failure)
	const FEEDBACK_TOOLS = new Set([...READ_TOOLS, "run_luau", "playtest"]);
	const OUT_LIMIT = { project_snapshot: 15000, get_script_source: 12000, verify: 9000, script_outline: 8000 };

	const TEMPLATES = [
		{ t: "🏃 10-stage Obby", p: "Build a 10-stage obby with rising difficulty: platforms, kill bricks, checkpoints with a stage-save system, and a stage indicator UI." },
		{ t: "🛒 Shop UI", p: "Build a modern shop UI (create_gui, dark theme) with 6 items, buy buttons, and a coin balance, plus a server script that validates purchases." },
		{ t: "🩺 Audit game", p: "Audit my entire game: take a project_snapshot, run verify, then fix every issue found and summarize." },
		{ t: "🐞 Fix errors", p: "Check the Studio Output (get_output), find the cause of the latest errors, fix them with edit_script, then verify." },
		{ t: "🌲 Map & decor", p: "Create a 200x200 hill terrain, then scatter random trees and rocks snapped to the ground, and set an evening lighting mood." },
		{ t: "⚔ Combat system", p: "Build a basic combat system: sword tool, server-side damage, cooldown, and remote anti-spam. Test it with playtest." },
	];

	// ------------------------------------------------------------------
	// PROMPT pasted into the AI chat
	// ------------------------------------------------------------------
	const PROMPT = [
		"From now on you are RobloxScripter v4: an agent that controls MY Roblox Studio DIRECTLY through an extension (32 tools). Don't tell me to copy-paste code; you place the objects, UI, and scripts in the game yourself, then check the results.",
		"",
		"HOW IT WORKS",
		"Whenever you need to read or change the game, send commands in ONE JSON block (format below), then stop and wait. The extension runs them in Studio and replies with a message starting with [RobloxScripter result]. Continue based on that result. Actions in one block run in order; if one fails, the whole batch is cancelled (rollback).",
		"",
		"HYBRID FORMAT (IMPORTANT: don't write long Lua code inside the JSON)",
		"1) Put Lua code in a SEPARATE code block whose first line is the marker --@rs:ID (a short unique ID, e.g. a1, a2, a3; don't reuse an ID from another message).",
		"2) Put the JSON block LAST in the message, referencing the code via source_ref / find_ref / replace_ref / code_ref.",
		"",
		FENCE + "lua",
		"--@rs:demo",
		'print("hello from RobloxScripter")',
		FENCE,
		"",
		FENCE + "json",
		'{"roblox_scripter":[{"tool":"create_script","script_type":"Script","parent_path":"ServerScriptService","name":"Hello","source_ref":"demo"},{"tool":"create_instance","class_name":"Part","parent_path":"Workspace","name":"Floor","properties":{"Anchored":true,"Size":[50,1,50],"Color":[120,120,120]}}],"_example":true}',
		FENCE,
		"(The example is illustration only: don't include the _example field in your real block.)",
		"",
		"TOOLS (each action = an object with a \"tool\" field + arguments)",
		"READ",
		"- project_snapshot {max_chars?}  -> summary of the whole game (structure, scripts + their functions, remotes). RUN THIS FIRST for an existing game.",
		"- list_children {path, depth?(1-4)}   - path \"game\" = root",
		"- find_instances {root?, class_name?, name_contains?, limit?}",
		"- get_properties {path, properties:[name,...]}   - get_selection {}",
		"- get_script_source {path, start_line?, end_line?}   - script_outline {path} (functions + line numbers; use it for large scripts, then read by range)",
		"- search_scripts {query, root?}   - get_output {level?:\"error\"|\"warning\"|\"all\", limit?}",
		"- verify {path?}  -> automatic audit: syntax of all scripts, remotes without handlers, loops without wait, deprecated wait()/spawn(), unanchored Parts, backdoor/dangerous patterns",
		"MODIFY",
		"- create_instance {class_name, parent_path, name?, properties?}   - set_properties {path, properties}",
		"- bulk_set_properties {root?, class_name?, name_contains?, tag?, properties, limit?}  -> change many objects at once (needs at least one filter)",
		"- create_tree {parent_path, tree:{class, name?, props?, children?:[...]}}  -> many objects/Models at once (max 300 nodes)",
		"- move_instance {path, new_parent_path}   - delete_instance {path}",
		"- clone_instance {path, parent_path?, name?, count?(1-100), offset?:[x,y,z], properties?}",
		"- group_instances {paths:[...], name?, class?:\"Model\"|\"Folder\", parent_path?}",
		"- arrange_instances {paths:[...] or parent_path, mode:\"grid\"|\"line\"|\"circle\"|\"align\", origin?:[x,y,z], spacing?:n or [sx,sz], columns?, axis?:\"X\"|\"Y\"|\"Z\", radius?, face_center?}",
		"- set_attributes {path, attributes:{name:value}}   - tag {path, add?:[...], remove?:[...]}",
		"SCRIPT",
		"- create_script {script_type:\"Script\"|\"LocalScript\"|\"ModuleScript\", parent_path, name, source_ref (or source), run_context?}",
		"- edit_script {path, source_ref}  OR  {path, find_ref, replace_ref} (find must match exactly & be unique)",
		"- replace_in_scripts {find_ref or find, replace_ref or replace, root?, dry_run?:true}  -> find/replace in ALL scripts (use dry_run first to see the impact)",
		"- run_luau {code_ref (or code), timeout?(1-60)}  -> run one-off Luau in Studio (edit mode), returning print/warn + the return value. For experiments, checking values, or bulk operations. Always goes through user approval.",
		"UI",
		"- create_gui {parent_path?(default StarterGui), theme?:\"dark\"|\"light\"|\"neon\"|{token:[r,g,b]}, tree}",
		"  tree = node {class?(default Frame), name, props?, text?, children?, plus shorthand:",
		"  corner:8 | stroke:{thickness,color,transparency} | gradient:{colors:[...],rotation} | padding:8 or [left,top,right,bottom] |",
		"  list:{direction:\"V\"|\"H\", padding, halign?, valign?} | grid:{cell:[w,h], padding} | aspect:1.5}",
		"  Colors can be theme tokens \"$bg\" \"$surface\" \"$surface2\" \"$primary\" \"$accent\" \"$text\" \"$subtext\" \"$danger\" \"$success\", or [r,g,b], or \"#RRGGBB\".",
		"  Defaults are already clean (font, colors, ResetOnSpawn=false); just set Size/Position/text. Design UI that is modern, consistent, and responsive (use Scale).",
		"WORLD",
		"- terrain {shape:\"block\"|\"ball\"|\"cylinder\"|\"hills\"|\"clear\", position, size?, radius?, height?, scale?, seed?, material?}  (hills = noise hills: size:[x,z], height, scale)",
		"- set_lighting {properties?, effects?:{\"Atmosphere\":{..},\"Sky\":{..},\"BloomEffect\":{..},\"ColorCorrectionEffect\":{..},\"SunRaysEffect\":{..},\"DepthOfFieldEffect\":{..}}}",
		"- insert_asset {asset_id, parent_path?, position?, name?, allow_scripts?}   - search_toolbox {query, page?}",
		"- scatter_instances {template_path (Model/Part sumber, keep it in ServerStorage), parent_path?, center:[x,y,z], size:[x,z], count(1-200), min_distance?, random_rotation?, scale_range?:[min,max], align_to_ground?(default true, raycast), seed?, name?}",
		"TEST",
		"- playtest {mode?:\"play\"|\"run\", duration?(3-120 seconds)}  -> run the game briefly, then return all errors/warnings during the playtest. (Experimental)",
		"",
		"RULES",
		"- path uses the GetFullName format: \"Workspace.Map.Door\", \"ServerScriptService\", \"StarterGui.ScreenGui\". Duplicate names: add #n (e.g. \"Workspace.Part#2\" = the 2nd child named Part). Names containing dots are still supported.",
		"- Property values: Vector3=[x,y,z], Vector2=[x,y], Color3=[r,g,b] 0-255 / \"#RRGGBB\", CFrame=[x,y,z] or [x,y,z,rotX,rotY,rotZ] degrees, UDim2=[xScale,xOffset,yScale,yOffset], UDim=[scale,offset], NumberRange=[min,max], Enum=name string (\"Neon\"), BrickColor=name, Instance=path string.",
		"- New Parts: Anchored=true unless physics is needed. Give them a clear Name.",
		"- Modern Luau: task.wait (not wait), task.spawn, +=. Server logic in a Script (ServerScriptService), input/UI in a LocalScript (StarterPlayerScripts/StarterGui), shared code in a ModuleScript (ReplicatedStorage). Validate all client input on the server.",
		"- Scripts with a syntax error are automatically REJECTED by the plugin and you get the error message: fix it and resend.",
		"- Workflow: (1) project_snapshot if the game already exists, (2) build the feature, (3) run verify, (4) for gameplay logic run playtest and read its errors, (5) fix until clean, then give a short summary.",
		"- For small edits use edit_script find/replace instead of rewriting the whole script. For large scripts: script_outline first, then get_script_source by line range.",
		"- Script changes, deletions, asset inserts, replace_in_scripts, and run_luau may be reviewed by me in Studio and I may reject them. If the result says 'REJECTED', don't repeat the exact same thing: ask me or change your approach.",
		"- A [RobloxScripter auto error] message contains errors from the Studio Output: find the source (get_script_source / search_scripts), fix it with edit_script, and summarize briefly.",
		"- One JSON block per message (last), with a short explanation outside the block. When you're done, give a short summary without a block.",
		"- Reply in the language I use.",
		"",
		"If you understand, reply briefly with \"Ready\" and then wait for my instructions.",
	].join("\n");

	// ------------------------------------------------------------------
	// util
	// ------------------------------------------------------------------
	const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
	function bg(msg) {
		return new Promise((res) => {
			try {
				chrome.runtime.sendMessage(msg, (r) => {
					void chrome.runtime.lastError;
					res(r || { error: "no_response" });
				});
			} catch (e) {
				res({ error: "ext_invalid" });
			}
		});
	}
	function hash(s) {
		let h = 5381;
		for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
		return String(h);
	}
	const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

	// ------------------------------------------------------------------
	// UI (Shadow DOM)
	// ------------------------------------------------------------------
	const CSS = `
	:host{all:initial}
	*{box-sizing:border-box;font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
	.root{--accent:#4C8DFF;--bg:#14151A;--panel:#1C1E26;--card:#232632;--line:#2E3242;--text:#E8EAF2;--sub:#8B91A7;--ok:#3DDC84;--bad:#FF5C5C;--warn:#FFB020;color:var(--text);font-size:12.5px;line-height:1.4;position:relative}
	button{font:inherit;color:inherit;cursor:pointer}
	.hide{display:none!important}
	/* FAB */
	.fab{position:relative;width:56px;height:56px;border-radius:16px;border:0;padding:0;background:#242422;box-shadow:0 8px 24px rgba(0,0,0,.5),0 0 0 2px color-mix(in srgb,var(--accent) 55%,transparent);display:flex;align-items:center;justify-content:center;transition:transform .15s}
	.fab img{width:100%;height:100%;border-radius:16px;display:block;pointer-events:none}
	.fab:hover{transform:scale(1.07)}
	.fabDot{position:absolute;right:2px;top:2px;width:13px;height:13px;border-radius:50%;background:var(--bad);border:2px solid #14151A}
	.fabDot.g{background:var(--ok)}.fabDot.y{background:var(--warn)}
	.fabBadge{position:absolute;left:-4px;bottom:-4px;min-width:20px;height:20px;padding:0 5px;border-radius:10px;background:var(--warn);color:#201400;font-size:11px;font-weight:800;display:flex;align-items:center;justify-content:center}
	/* PANEL */
	.panel{width:360px;max-height:min(640px,calc(100vh - 28px));display:flex;flex-direction:column;background:linear-gradient(180deg,#1D1F28,#15161C);border:1px solid var(--line);border-radius:18px;box-shadow:0 22px 60px rgba(0,0,0,.6),0 0 0 1px rgba(255,255,255,.03) inset;overflow:hidden}
	.head{display:flex;align-items:center;gap:10px;padding:11px 12px;background:linear-gradient(135deg,color-mix(in srgb,var(--accent) 28%,#1C1E26),#1C1E26 70%);border-bottom:1px solid var(--line);cursor:grab;user-select:none;touch-action:none}
	.head:active{cursor:grabbing}
	.logo{width:32px;height:32px;border-radius:9px;flex:none;box-shadow:0 4px 12px rgba(0,0,0,.4);overflow:hidden;background:#242422}
	.logo img{width:100%;height:100%;display:block}
	.ttl{flex:1;min-width:0;display:flex;flex-direction:column}
	.ttl b{font-size:13.5px;letter-spacing:.2px}
	.ttl b i{font-style:normal;font-size:10px;font-weight:700;background:rgba(255,255,255,.12);padding:1px 6px;border-radius:8px;margin-left:6px;vertical-align:1px}
	.ttl span{font-size:11px;color:var(--sub);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
	.dot{width:10px;height:10px;border-radius:50%;background:var(--bad);flex:none;box-shadow:0 0 0 3px rgba(255,255,255,.05)}
	.dot.g{background:var(--ok);box-shadow:0 0 10px var(--ok)}.dot.y{background:var(--warn)}
	.ib{background:rgba(255,255,255,.07);border:0;border-radius:8px;width:26px;height:26px;color:#ccd;font-size:14px;line-height:1;flex:none}
	.ib:hover{background:rgba(255,255,255,.14)}
	/* TABS */
	.tabs{display:flex;gap:4px;padding:8px 10px 0;background:var(--panel)}
	.tabs button{flex:1;background:none;border:0;border-bottom:2px solid transparent;color:var(--sub);padding:7px 4px 8px;font-weight:600;font-size:12px}
	.tabs button b{font-size:10px;background:rgba(255,255,255,.1);padding:1px 6px;border-radius:8px;margin-left:4px}
	.tabs button b.hot{background:var(--warn);color:#201400}
	.tabs button.on{color:var(--text);border-bottom-color:var(--accent)}
	.tabs button:hover{color:var(--text)}
	.toast{position:absolute;left:50%;top:100px;transform:translate(-50%,-6px);background:#0c0d11;border:1px solid var(--line);color:var(--text);padding:7px 13px;border-radius:20px;font-size:11.5px;box-shadow:0 8px 24px rgba(0,0,0,.5);opacity:0;pointer-events:none;transition:.2s;z-index:5;white-space:nowrap;max-width:92%;overflow:hidden;text-overflow:ellipsis}
	.toast.show{opacity:1;transform:translate(-50%,0)}
	.toast.ok{border-color:var(--ok)}.toast.bad{border-color:var(--bad)}
	.views{flex:1;min-height:0;overflow:auto;background:var(--bg)}
	.views::-webkit-scrollbar{width:7px}.views::-webkit-scrollbar-thumb{background:#2c2f3d;border-radius:4px}
	.view{display:none;padding:10px;flex-direction:column;gap:9px}
	.view.on{display:flex}
	/* quick actions */
	.qa{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
	.qa button{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:7px 2px;font-size:11px;font-weight:600;display:flex;flex-direction:column;align-items:center;gap:2px}
	.qa button span{font-size:15px}
	.qa button:hover{border-color:var(--accent);background:color-mix(in srgb,var(--accent) 14%,var(--card))}
	select,input[type=text],input[type=search]{width:100%;background:var(--card);color:var(--text);border:1px solid var(--line);border-radius:9px;padding:7px 9px;font-size:12px;outline:0}
	select{display:none}
	input:focus{border-color:var(--accent)}
	.empty{text-align:center;color:var(--sub);padding:26px 14px;border:1px dashed var(--line);border-radius:12px;font-size:12px}
	.empty big{display:block;font-size:26px;margin-bottom:6px}
	/* action cards */
	.card{background:var(--card);border:1px solid var(--line);border-radius:13px;overflow:hidden;transition:border-color .2s}
	.card.run{border-color:var(--accent)}.card.ok{border-color:color-mix(in srgb,var(--ok) 55%,var(--line))}.card.bad{border-color:color-mix(in srgb,var(--bad) 60%,var(--line))}
	.card.err{border-color:color-mix(in srgb,var(--bad) 55%,var(--line))}
	.ch{display:flex;align-items:center;gap:9px;padding:9px 10px;cursor:pointer}
	.cic{width:30px;height:30px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:12px;flex:none}
	.cti{flex:1;min-width:0}
	.cti b{display:block;font-size:12.5px}
	.cti small{display:block;color:var(--sub);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
	.badge{font-size:10.5px;font-weight:700;padding:3px 8px;border-radius:10px;background:rgba(255,255,255,.1);color:var(--sub);white-space:nowrap;flex:none}
	.card.run .badge{background:color-mix(in srgb,var(--accent) 25%,transparent);color:#bcd4ff}
	.card.ok .badge{background:color-mix(in srgb,var(--ok) 20%,transparent);color:var(--ok)}
	.card.bad .badge,.card.err .badge{background:color-mix(in srgb,var(--bad) 20%,transparent);color:var(--bad)}
	.chev{color:var(--sub);font-size:11px;transition:transform .15s;flex:none}
	.card.open .chev{transform:rotate(180deg)}
	.x{background:none;border:0;color:var(--sub);font-size:13px;padding:2px 4px;border-radius:6px;flex:none}
	.x:hover{background:rgba(255,255,255,.1);color:var(--text)}
	.pb{height:2px;background:transparent;overflow:hidden}
	.card.run .pb{background:rgba(255,255,255,.07)}
	.card.run .pb::after{content:"";display:block;height:100%;width:35%;background:var(--accent);animation:sl 1.1s ease-in-out infinite}
	@keyframes sl{0%{margin-left:-35%}100%{margin-left:100%}}
	.note{padding:0 10px 8px;color:var(--sub);font-size:11px}
	.cb{display:none;padding:2px 10px 8px;flex-direction:column;gap:6px}
	.card.open .cb{display:flex}
	.row{background:rgba(0,0,0,.22);border-radius:9px;padding:7px 8px;display:flex;flex-direction:column;gap:4px}
	.rt{display:flex;align-items:center;gap:7px}
	.rt .tag{font-size:10px;font-weight:800;padding:1px 6px;border-radius:6px}
	.rt b{font-family:ui-monospace,Consolas,monospace;font-size:11.5px}
	.rt em{font-style:normal;color:var(--sub);font-size:11px;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
	.rt .st{font-weight:800;flex:none}
	.st.ok{color:var(--ok)}.st.bad{color:var(--bad)}
	.out{margin:0;font-family:ui-monospace,Consolas,monospace;font-size:11px;color:#b8bdd2;white-space:pre-wrap;word-break:break-word;max-height:150px;overflow:auto;border-top:1px solid rgba(255,255,255,.06);padding-top:5px}
	.cf{display:flex;gap:6px;padding:0 10px 10px;flex-wrap:wrap}
	.btn{background:var(--accent);color:#fff;border:0;border-radius:9px;padding:6px 12px;font-weight:700;font-size:11.5px}
	.btn:hover{filter:brightness(1.12)}
	.btn.s{background:rgba(255,255,255,.09);color:var(--text)}
	.btn:disabled{opacity:.45;cursor:default;filter:none}
	/* tools */
	.srch{position:sticky;top:-10px;z-index:2;background:var(--bg);padding-bottom:2px}
	.chips{display:flex;gap:5px;flex-wrap:wrap}
	.chip{background:var(--card);border:1px solid var(--line);color:var(--sub);border-radius:14px;padding:3px 9px;font-size:11px;font-weight:600}
	.chip.on{background:color-mix(in srgb,var(--accent) 22%,var(--card));border-color:var(--accent);color:var(--text)}
	.h6{margin:2px 0 -3px;font-size:10.5px;font-weight:800;letter-spacing:.8px;text-transform:uppercase;color:var(--sub)}
	.tpl{display:grid;grid-template-columns:1fr 1fr;gap:6px}
	.tpl button{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:8px;text-align:left;font-size:11.5px;font-weight:600}
	.tpl button:hover{border-color:var(--accent)}
	.tl{display:flex;align-items:center;gap:9px;background:var(--card);border:1px solid var(--line);border-radius:11px;padding:8px 9px}
	.tl .cic{width:26px;height:26px;font-size:11px;border-radius:8px}
	.tl>div:not(.cic){flex:1;min-width:0}
	.tl .cic{flex:none}
	.tl b{display:block;font-family:ui-monospace,Consolas,monospace;font-size:11.5px}
	.tl small{display:block;color:var(--sub);font-size:11px}
	.tl button{background:rgba(255,255,255,.09);border:0;border-radius:8px;padding:5px 9px;font-size:11px;font-weight:700;flex:none}
	.tl button:hover{background:var(--accent);color:#fff}
	/* settings */
	.set{display:flex;align-items:center;gap:10px;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:10px;cursor:pointer}
	.set div{flex:1}.set b{display:block;font-size:12.5px}.set small{color:var(--sub);font-size:11px}
	.sw{position:relative;width:38px;height:22px;flex:none}
	.sw input{position:absolute;opacity:0;inset:0;margin:0;cursor:pointer}
	.sw i{position:absolute;inset:0;background:#3a3e50;border-radius:11px;transition:.15s}
	.sw i::after{content:"";position:absolute;left:3px;top:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:.15s}
	.sw input:checked+i{background:var(--accent)}
	.sw input:checked+i::after{left:19px}
	.sws{display:flex;gap:9px;align-items:center}
	.sws button{width:24px;height:24px;border-radius:50%;border:2px solid transparent;padding:0}
	.sws button.on{border-color:#fff}
	.box{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:10px;display:flex;flex-direction:column;gap:8px}
	.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;text-align:center}
	.stats div{background:rgba(0,0,0,.22);border-radius:9px;padding:7px 2px}
	.stats b{display:block;font-size:17px}.stats small{color:var(--sub);font-size:10.5px}
	.ft{padding:7px 12px;border-top:1px solid var(--line);background:var(--panel);color:var(--sub);font-size:10.5px;display:flex;justify-content:space-between}
	/* ===== animations ===== */
	.panel{transform-origin:bottom right;animation:panelIn .38s cubic-bezier(.2,.9,.3,1.15) both}
	.panel.out{animation:panelOut .17s ease-in forwards}
	.fab{transform-origin:center;animation:fabIn .4s cubic-bezier(.2,1.5,.4,1) both}
	.fab.out{animation:fabOut .15s ease-in forwards}
	.fab:active{transform:scale(.94)}
	.fab::before{content:"";position:absolute;inset:0;border-radius:16px;pointer-events:none}
	.fab:has(.fabBadge:not(.hide))::before{animation:ring 1.6s ease-out infinite}
	.fabDot.g,.dot.g{animation:dotp 2s ease-in-out infinite}
	.fabBadge:not(.hide){animation:pop .4s cubic-bezier(.2,1.6,.4,1)}
	.logo{animation:glow 3.5s ease-in-out infinite}
	.head{background-size:200% 100%}
	.tabs button{position:relative;transition:color .2s}
	.tabs button.on{border-bottom-color:transparent}
	.tabs button::after{content:"";position:absolute;left:14%;right:14%;bottom:-2px;height:2px;border-radius:2px;background:var(--accent);transform:scaleX(0);transition:transform .28s cubic-bezier(.3,.9,.3,1)}
	.tabs button.on::after{transform:scaleX(1)}
	.tabs button b.hot{animation:pulse 1.4s ease-in-out infinite}
	.view.on{animation:viewIn .3s ease both}
	.qa button,.tpl button,.tl,.chip,.btn,.set,.x,.ib{transition:transform .15s,border-color .2s,background .2s,box-shadow .2s,filter .15s}
	.qa button:hover,.tpl button:hover{transform:translateY(-2px);box-shadow:0 6px 14px rgba(0,0,0,.35)}
	.qa button:active,.tpl button:active,.btn:active,.tl button:active,.chip:active,.ib:active{transform:scale(.95)}
	.qa button span{transition:transform .2s}.qa button:hover span{transform:scale(1.25) rotate(-6deg)}
	.qa button,.tpl button,.tl,.chip{animation:popUp .4s cubic-bezier(.2,.9,.3,1.2) both}
	.qa button:nth-child(2),.tpl button:nth-child(2){animation-delay:.04s}.qa button:nth-child(3),.tpl button:nth-child(3){animation-delay:.08s}
	.qa button:nth-child(4),.tpl button:nth-child(4){animation-delay:.12s}.tpl button:nth-child(5){animation-delay:.16s}.tpl button:nth-child(6){animation-delay:.2s}
	.tl:nth-child(2){animation-delay:.03s}.tl:nth-child(3){animation-delay:.06s}.tl:nth-child(4){animation-delay:.09s}.tl:nth-child(5){animation-delay:.12s}.tl:nth-child(n+6){animation-delay:.15s}
	.card{animation:cardIn .4s cubic-bezier(.2,.9,.3,1.1) both}
	.card.leaving{animation:cardOut .22s ease-in forwards}
	.card.run{animation:cardIn .4s both,glowCard 1.8s ease-in-out .4s infinite}
	.card.open .cb{animation:viewIn .28s ease both}
	.card:hover{box-shadow:0 6px 18px rgba(0,0,0,.3)}
	.row{animation:rowIn .3s ease both}
	.empty big{animation:floaty 2.6s ease-in-out infinite}
	.toast{transition:opacity .25s,transform .3s cubic-bezier(.2,1.4,.4,1)}
	.sws button{transition:transform .15s}.sws button:hover{transform:scale(1.2)}
	@keyframes panelIn{from{opacity:0;transform:translateY(16px) scale(.92)}to{opacity:1;transform:none}}
	@keyframes panelOut{to{opacity:0;transform:translateY(12px) scale(.94)}}
	@keyframes fabIn{from{opacity:0;transform:scale(.4) rotate(-20deg)}to{opacity:1;transform:none}}
	@keyframes fabOut{to{opacity:0;transform:scale(.5)}}
	@keyframes ring{0%{box-shadow:0 0 0 0 color-mix(in srgb,var(--warn) 70%,transparent)}100%{box-shadow:0 0 0 16px transparent}}
	@keyframes dotp{0%,100%{box-shadow:0 0 4px var(--ok)}50%{box-shadow:0 0 13px var(--ok)}}
	@keyframes glow{0%,100%{box-shadow:0 4px 12px rgba(0,0,0,.4)}50%{box-shadow:0 4px 18px color-mix(in srgb,var(--accent) 55%,transparent)}}
	@keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.18)}}
	@keyframes pop{0%{transform:scale(.3);opacity:0}100%{transform:scale(1);opacity:1}}
	@keyframes viewIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
	@keyframes popUp{from{opacity:0;transform:translateY(8px) scale(.94)}to{opacity:1;transform:none}}
	@keyframes cardIn{from{opacity:0;transform:translateY(-10px) scale(.97)}to{opacity:1;transform:none}}
	@keyframes cardOut{to{opacity:0;transform:translateX(30px) scale(.95)}}
	@keyframes glowCard{0%,100%{box-shadow:0 0 0 0 transparent}50%{box-shadow:0 0 14px color-mix(in srgb,var(--accent) 45%,transparent)}}
	@keyframes rowIn{from{opacity:0;transform:translateX(-8px)}to{opacity:1;transform:none}}
	@keyframes floaty{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
	@media (prefers-reduced-motion:reduce){*{animation-duration:.01ms!important;transition-duration:.01ms!important}}
	`;

	const host = document.createElement("div");
	host.style.cssText = "all:initial;position:fixed;right:16px;bottom:16px;z-index:2147483647;";
	const root = host.attachShadow({ mode: window.__RS_TEST ? "open" : "closed" });
	root.innerHTML = `
	<style>${CSS}</style>
	<div class="root" id="rootEl">
		<button class="fab hide" id="fab" title="Open RobloxScripter (Alt+R)"><img src="${LOGO}" alt="RS"><i class="fabDot" id="fabDot"></i><b class="fabBadge hide" id="fabBadge"></b></button>
		<div class="panel" id="panel">
			<div class="head" id="head">
				<div class="logo"><img src="${LOGO}" alt="RS" width="32" height="32"></div>
				<div class="ttl"><b>RobloxScripter<i>v4</i></b><span id="st">checking…</span></div>
				<i class="dot" id="dot"></i>
				<button class="ib" id="min" title="Minimize (Alt+R)">–</button>
			</div>
			<div class="tabs" id="tabs">
				<button data-tab="act" class="on">Actions<b id="cnt" class="hide"></b></button>
				<button data-tab="tools">Tools<b>${TOOLS.length}</b></button>
				<button data-tab="set">Settings</button>
			</div>
			<div class="toast" id="toast"></div>
			<div class="views">
				<section class="view on" id="v-act">
					<div class="qa">
						<button id="qPrompt"><span>📋</span>Prompt</button>
						<button id="qSnap"><span>📸</span>Snapshot</button>
						<button id="qVerify"><span>🧪</span>Verify</button>
						<button id="qErr"><span>🐞</span>Error</button>
					</div>
					<select id="sel" title="Target Studio window"></select>
					<div class="empty" id="empty"><big>⚡</big>No actions yet.<br>Ask the AI to build something — action cards will appear here.</div>
					<div id="list" style="display:flex;flex-direction:column;gap:8px"></div>
				</section>
				<section class="view" id="v-tools">
					<div class="srch"><input type="search" id="q" placeholder="Search tools… (${TOOLS.length} available)" /></div>
					<div class="h6">Quick templates</div>
					<div class="tpl" id="tpl"></div>
					<div class="chips" id="chips"></div>
					<div id="tlist" style="display:flex;flex-direction:column;gap:6px"></div>
				</section>
				<section class="view" id="v-set">
					<label class="set"><div><b>Auto-run AI commands</b><small>Cards run immediately when the AI finishes writing</small></div><span class="sw"><input type="checkbox" id="chkAuto"><i></i></span></label>
					<label class="set"><div><b>Auto-send results to chat</b><small>The AI gets the results and continues on its own</small></div><span class="sw"><input type="checkbox" id="chkSend"><i></i></span></label>
					<label class="set"><div><b>Auto-debug</b><small>Send Studio Output errors to the AI</small></div><span class="sw"><input type="checkbox" id="chkDebug"><i></i></span></label>
					<label class="set"><div><b>Auto-paste prompt</b><small>In new chats (you press send)</small></div><span class="sw"><input type="checkbox" id="chkPrompt"><i></i></span></label>
					<div class="box"><b>Accent color</b><div class="sws" id="sws"></div></div>
					<div class="box"><b>Session stats</b>
						<div class="stats"><div><b id="sB">0</b><small>batch</small></div><div><b id="sOk" style="color:var(--ok)">0</b><small>success</small></div><div><b id="sBad" style="color:var(--bad)">0</b><small>failed</small></div></div>
						<div style="display:flex;gap:6px"><button class="btn s" id="bClear" style="flex:1">Clear all cards</button><button class="btn s" id="bPos" style="flex:1">Reset position</button></div>
					</div>
				</section>
			</div>
			<div class="ft"><span>Alt+R: hide / show</span><span>${TOOLS.length} tools</span></div>
		</div>
	</div>`;
	document.documentElement.appendChild(host);

	const $ = (id) => root.getElementById(id);
	const rootEl = $("rootEl"), panel = $("panel"), fab = $("fab"), head = $("head");
	const dot = $("dot"), st = $("st"), list = $("list"), sel = $("sel"), emptyEl = $("empty");
	const state = { auto: false, autoSend: false, autoDebug: false, autoPrompt: false, min: false, accent: "#4C8DFF", tab: "act", pos: null };
	const stats = { batches: 0, ok: 0, bad: 0 };

	// ---------- toast ----------
	let toastT = null;
	function toast(msg, kind) {
		const t = $("toast");
		t.textContent = msg;
		t.className = "toast show " + (kind || "");
		clearTimeout(toastT);
		toastT = setTimeout(() => (t.className = "toast"), 2200);
	}

	// ---------- aksen warna ----------
	const ACCENTS = ["#4C8DFF", "#A78BFA", "#F472B6", "#3DDC84", "#FFB020"];
	function applyAccent() {
		rootEl.style.setProperty("--accent", state.accent);
		root.querySelectorAll("#sws button").forEach((b) => b.classList.toggle("on", b.dataset.c === state.accent));
	}
	ACCENTS.forEach((c) => {
		const b = document.createElement("button");
		b.dataset.c = c;
		b.style.background = c;
		b.onclick = () => {
			state.accent = c;
			applyAccent();
			save({ accent: c });
		};
		$("sws").appendChild(b);
	});

	function save(obj) {
		try {
			chrome.storage.local.set(obj);
		} catch (e) {}
	}

	// ---------- tab ----------
	function setTab(name) {
		state.tab = name;
		root.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("on", b.dataset.tab === name));
		root.querySelectorAll(".view").forEach((v) => v.classList.toggle("on", v.id === "v-" + name));
		save({ tab: name });
	}
	root.querySelectorAll("#tabs button").forEach((b) => (b.onclick = () => setTab(b.dataset.tab)));

	// ---------- posisi, drag, minimize ----------
	function applyPos() {
		const p = state.pos || { r: 16, b: 16 };
		host.style.right = clamp(p.r, 0, Math.max(0, innerWidth - 60)) + "px";
		host.style.bottom = clamp(p.b, 0, Math.max(0, innerHeight - 60)) + "px";
	}
	function applyMin(anim) {
		const showEl = state.min ? fab : panel, goneEl = state.min ? panel : fab;
		clearTimeout(applyMin.t);
		showEl.classList.remove("out");
		const fin = () => {
			goneEl.classList.add("hide");
			goneEl.classList.remove("out");
			showEl.classList.remove("hide");
		};
		if (anim === true && !goneEl.classList.contains("hide")) {
			goneEl.classList.add("out");
			applyMin.t = setTimeout(fin, 170);
		} else fin();
	}
	function setMin(v) {
		state.min = v;
		applyMin(true);
		save({ min: v });
	}
	function makeDraggable(handle, onTap) {
		let d = null;
		handle.addEventListener("pointerdown", (e) => {
			if (e.button !== 0 || e.target.closest("button:not(.fab)")) return;
			const p = state.pos || { r: 16, b: 16 };
			d = { sx: e.clientX, sy: e.clientY, r: p.r, b: p.b, moved: false };
			handle.setPointerCapture(e.pointerId);
		});
		handle.addEventListener("pointermove", (e) => {
			if (!d) return;
			const dx = e.clientX - d.sx, dy = e.clientY - d.sy;
			if (Math.abs(dx) + Math.abs(dy) > 4) d.moved = true;
			if (!d.moved) return;
			state.pos = { r: clamp(d.r - dx, 0, innerWidth - 60), b: clamp(d.b - dy, 0, innerHeight - 60) };
			applyPos();
		});
		handle.addEventListener("pointerup", () => {
			if (!d) return;
			if (d.moved) save({ pos: state.pos });
			else if (onTap) onTap();
			d = null;
		});
	}
	makeDraggable(head);
	makeDraggable(fab, () => setMin(false));
	$("min").onclick = () => setMin(true);
	window.addEventListener("keydown", (e) => {
		if (e.altKey && !e.ctrlKey && !e.metaKey && e.key.toLowerCase() === "r") {
			e.preventDefault();
			setMin(!state.min);
		}
	});
	window.addEventListener("resize", applyPos);
	$("bPos").onclick = () => {
		state.pos = null;
		applyPos();
		save({ pos: null });
		toast("Panel position reset");
	};
	chrome.runtime.onMessage.addListener((m) => {
		if (m && m.type === "show") setMin(false);
	});

	// ---------- settings ----------
	const chkMap = { chkAuto: "auto", chkSend: "autoSend", chkDebug: "autoDebug", chkPrompt: "autoPrompt" };
	Object.entries(chkMap).forEach(([id, key]) => {
		$(id).onchange = () => {
			state[key] = $(id).checked;
			save({ [key]: state[key] });
		};
	});
	try {
		chrome.storage.local.get({ auto: false, autoSend: false, autoDebug: false, autoPrompt: false, min: false, accent: "#4C8DFF", tab: "act", pos: null }, (v) => {
			Object.assign(state, v);
			Object.entries(chkMap).forEach(([id, key]) => ($(id).checked = !!state[key]));
			applyAccent();
			applyPos();
			applyMin();
			setTab(state.tab === "tools" || state.tab === "set" ? state.tab : "act");
		});
	} catch (e) {}
	applyAccent();
	applyPos();
	applyMin();

	function updateStats() {
		$("sB").textContent = stats.batches;
		$("sOk").textContent = stats.ok;
		$("sBad").textContent = stats.bad;
	}

	// ---------- badge for number of pending cards ----------
	function updateBadges() {
		const pending = list.querySelectorAll(".card.idle, .card.err").length;
		const cnt = $("cnt"), fb = $("fabBadge");
		cnt.textContent = pending;
		cnt.classList.toggle("hide", !pending);
		cnt.classList.toggle("hot", !!pending);
		fb.textContent = pending;
		fb.classList.toggle("hide", !pending);
		emptyEl.classList.toggle("hide", list.children.length > 0);
	}

	// ---------- status server / plugin ----------
	let lastSeq = null;
	let selKey = "";
	function setConn(cls, text) {
		dot.className = "dot " + cls;
		$("fabDot").className = "fabDot " + cls;
		st.textContent = text;
	}
	async function refreshStatus() {
		const r = await bg({ type: "status" });
		if (r.error === "bad_token") return setConn("y", "not paired — open the dashboard & click Connect");
		if (r.error) return setConn("", "server is down — run node server.js");
		if (lastSeq === null && typeof r.eventSeq === "number") lastSeq = r.eventSeq;
		if (!r.pluginConnected) setConn("y", "server OK · Studio plugin not connected yet");
		else setConn("g", "connected to Studio" + ((r.plugins || []).length > 1 ? " · " + r.plugins.length + " windows" : ""));
		const ps = r.plugins || [];
		const key = JSON.stringify(ps.map((p) => [p.sid, p.name, p.active]));
		if (key !== selKey) {
			selKey = key;
			sel.innerHTML = "";
			ps.forEach((p) => {
				const o = document.createElement("option");
				o.value = p.sid;
				o.textContent = "🎮 Studio: " + p.name;
				o.selected = p.active;
				sel.appendChild(o);
			});
			sel.style.display = ps.length > 1 ? "block" : "none";
		}
	}
	sel.onchange = () => bg({ type: "select", sid: sel.value });
	refreshStatus();
	setInterval(refreshStatus, 3000);

	// ------------------------------------------------------------------
	// Write into the AI site's chat box
	// ------------------------------------------------------------------
	function findInput() {
		const els = [
			...document.querySelectorAll('textarea, [contenteditable=""], [contenteditable="true"], [role="textbox"]'),
		].filter((e) => {
			const r = e.getBoundingClientRect();
			return r.width > 80 && r.height > 12 && getComputedStyle(e).visibility !== "hidden";
		});
		if (!els.length) return null;
		if (els.includes(document.activeElement)) return document.activeElement;
		els.sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top);
		return els[0];
	}

	function setText(el, text) {
		el.focus();
		if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
			const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), "value").set;
			setter.call(el, (el.value ? el.value + "\n" : "") + text);
			el.dispatchEvent(new Event("input", { bubbles: true }));
			return true;
		}
		const s = window.getSelection();
		const range = document.createRange();
		range.selectNodeContents(el);
		range.collapse(false);
		s.removeAllRanges();
		s.addRange(range);
		let ok = false;
		try {
			ok = document.execCommand("insertText", false, text);
		} catch (e) {}
		if (!ok) {
			const dt = new DataTransfer();
			dt.setData("text/plain", text);
			el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
		}
		return true;
	}

	function trySubmit(el) {
		let scope = el;
		for (let i = 0; i < 6 && scope.parentElement; i++) scope = scope.parentElement;
		const btns = [...scope.querySelectorAll("button, [role=button]")].filter((b) => {
			const label = (
				(b.getAttribute("aria-label") || "") + " " + (b.getAttribute("data-testid") || "") + " " + (b.textContent || "")
			).toLowerCase();
			return /send|kirim|submit/.test(label) && !b.disabled && b.getAttribute("aria-disabled") !== "true";
		});
		if (btns.length) {
			btns[btns.length - 1].click();
			return;
		}
		el.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
	}

	async function insertIntoChat(text, submit) {
		registerSent(String(text || ""));
		const el = findInput();
		if (!el) {
			toast("Chat box not found on this page", "bad");
			return false;
		}
		setText(el, text);
		if (submit) {
			await sleep(500);
			trySubmit(el);
		}
		return true;
	}

	// ---------- Actions tab: quick buttons ----------
	$("qPrompt").onclick = async () => {
		if (await insertIntoChat(PROMPT, false)) toast("Prompt pasted — press send", "ok");
	};

	// ------------------------------------------------------------------
	// Command cards
	// ------------------------------------------------------------------
	let busyRuns = 0;
	const seen = new Map(); // command key -> time seen (Infinity = old history)

	function isDup(key) {
		const t = seen.get(key);
		const now = Date.now();
		if (t !== undefined && (t === Infinity || now - t < 30000)) return true;
		seen.set(key, now);
		return false;
	}

	function formatResults(id, results) {
		const lines = ["[RobloxScripter result #" + id + "]"];
		results.forEach((r, i) => {
			const limit = OUT_LIMIT[r.tool] || 6000;
			let out = String(r.output == null ? "" : r.output);
			if (out.length > limit) out = out.slice(0, limit) + "\n...(truncated)";
			lines.push(`${i + 1}. ${r.tool} ${r.ok ? "✔" : "✘ FAILED"}`);
			if (out) lines.push(out);
		});
		return lines.join("\n");
	}

	function normalize(arr) {
		return arr.map((a) => {
			const c = Object.assign({}, a);
			for (const k of ["source", "find", "replace", "code"]) {
				if (Array.isArray(c[k])) c[k] = c[k].join("\n");
			}
			return c;
		});
	}

	function rmCard(w) {
		w.classList.add("leaving");
		setTimeout(() => {
			w.remove();
			updateBadges();
		}, 220);
	}

	function trimList() {
		while (list.children.length > 12) list.lastChild.remove();
		updateBadges();
	}

	function el(tag, cls, text) {
		const e = document.createElement(tag);
		if (cls) e.className = cls;
		if (text != null) e.textContent = text;
		return e;
	}

	function catOf(tool) {
		const t = TOOL_BY.get(tool);
		return CATS[t ? t.c : "baca"];
	}

	function argHint(a) {
		const v = a.path || a.parent_path || a.root || a.template_path || a.name || a.query || a.class_name || a.mode || a.shape || "";
		return typeof v === "string" ? v : "";
	}

	function tagStyle(e, color) {
		e.style.background = color + "26";
		e.style.color = color;
	}

	function addCard(actions, note, key) {
		const card = {
			actions,
			key: key || null,
			id: null,
			resultText: "",
			noAuto: false,
			state: "idle",
			rows: [],
		};
		const wrap = el("div", "card idle");
		card.wrap = wrap;

		// card header
		const ch = el("div", "ch");
		const first = catOf(actions[0].tool);
		const ic = el("div", "cic", first.icon);
		tagStyle(ic, first.color);
		const cti = el("div", "cti");
		const names = [...new Set(actions.map((a) => a.tool))];
		cti.append(el("b", "", `${actions.length} action${actions.length === 1 ? "" : "s"}`), el("small", "", names.slice(0, 3).join(" · ") + (names.length > 3 ? " +" + (names.length - 3) : "")));
		const badge = el("span", "badge", "Ready");
		const chev = el("span", "chev", "▾");
		const x = el("button", "x", "✕");
		x.title = "Close card";
		x.onclick = (ev) => {
			ev.stopPropagation();
			if (card.state === "run") return;
			rmCard(wrap);
		};
		ch.append(ic, cti, badge, chev, x);
		ch.onclick = () => wrap.classList.toggle("open");
		const pb = el("div", "pb");
		const noteEl = el("div", "note", note || "");
		if (!note) noteEl.classList.add("hide");

		// body (action list)
		const cb = el("div", "cb");
		actions.forEach((a) => {
			const c = catOf(a.tool);
			const row = el("div", "row");
			const rt = el("div", "rt");
			const tag = el("span", "tag", c.icon);
			tagStyle(tag, c.color);
			const nm = el("b", "", a.tool);
			const hint = el("em", "", argHint(a));
			const stt = el("span", "st", "");
			rt.append(tag, nm, hint, stt);
			row.append(rt);
			cb.append(row);
			card.rows.push({ row, stt });
		});

		// card footer
		const cf = el("div", "cf");
		const run = el("button", "btn", "▶ Run");
		run.onclick = () => runCard(card);
		const sendBack = el("button", "btn s hide", "Send to chat");
		sendBack.onclick = async () => {
			if (await insertIntoChat(card.resultText, state.autoSend)) toast(state.autoSend ? "Result sent to the AI" : "Result pasted into chat", "ok");
		};
		const copy = el("button", "btn s hide", "Copy");
		copy.onclick = async () => {
			try {
				await navigator.clipboard.writeText(card.resultText);
				toast("Result copied", "ok");
			} catch (e) {
				toast("Copy failed", "bad");
			}
		};
		cf.append(run, sendBack, copy);

		wrap.append(ch, pb, noteEl, cb, cf);
		list.prepend(wrap);

		card.runBtn = run;
		card.sendBtn = sendBack;
		card.copyBtn = copy;
		card.setState = (s, text) => {
			card.state = s;
			wrap.className = "card " + s + (wrap.classList.contains("open") ? " open" : "") + (wrap.classList.contains("leaving") ? " leaving" : "");
			badge.textContent = text;
			if (card.onState) card.onState(s, text);
			updateBadges();
		};
		card.setNote = (t, cls) => {
			noteEl.textContent = t;
			noteEl.classList.toggle("hide", !t);
			noteEl.style.color = cls === "bad" ? "var(--bad)" : cls === "ok" ? "var(--ok)" : "";
		};
		card.setStatus = card.setNote; // compatible with old callers
		card.open = () => wrap.classList.add("open");
		trimList();
		return card;
	}

	async function runCard(card) {
		card.runBtn.disabled = true;
		busyRuns++;
		try {
			card.t0 = Date.now();
			card.setState("run", "Sending…");
			card.setNote("");
			const r = await bg({ type: "send", actions: card.actions });
			if (r.error) {
				card.setState("bad", "Failed");
				card.setNote(r.error === "bad_token" ? "Wrong token — enter it in the extension popup" : "Server is down — run node server.js", "bad");
				card.runBtn.disabled = false;
				return;
			}
			card.id = r.id;
			card.setState("run", "Running");
			card.setNote(
				r.pluginConnected
					? "Running in Studio… (if review mode is on, approve it in the Studio panel)"
					: "Waiting for the Studio plugin (open Plugins > RobloxScripter)…"
			);
			let errs = 0;
			for (let i = 0; i < 90; i++) {
				const res = await bg({ type: "result", id: card.id, wait: true });
				if (res && res.done) {
					await finish(card, res.results);
					return;
				}
				if (res && res.error) {
					if (++errs > 5) break;
					await sleep(2000);
				}
			}
			card.setState("bad", "Timeout");
			card.setNote("No response from Studio", "bad");
			card.runBtn.disabled = false;
		} finally {
			busyRuns--;
		}
	}

	async function finish(card, results) {
		const okCount = results.filter((x) => x.ok).length;
		const allOk = okCount === results.length;
		const rejected = results.some((x) => /REJECTED/.test(String(x.output)));
		stats.batches++;
		stats.ok += okCount;
		stats.bad += results.length - okCount;
		updateStats();

		const secs = ((Date.now() - (card.t0 || Date.now())) / 1000).toFixed(1);
		card.setState(allOk ? "ok" : "bad", rejected ? "Rejected" : (allOk ? `✔ ${okCount}/${results.length}` : `✘ ${okCount}/${results.length}`) + ` · ${secs}s`);
		card.setNote(rejected ? "Rejected in Studio" : "");
		results.forEach((r, i) => {
			const row = card.rows[i];
			if (!row) return;
			row.stt.textContent = r.ok ? "✔" : "✘";
			row.stt.className = "st " + (r.ok ? "ok" : "bad");
			const out = String(r.output == null ? "" : r.output);
			if (out) {
				const pre = el("pre", "out", out.length > 1500 ? out.slice(0, 1500) + "\n…(truncated in view)" : out);
				row.row.append(pre);
			}
		});
		if (!allOk || results.some((x) => FEEDBACK_TOOLS.has(x.tool))) card.open();
		card.resultText = formatResults(card.id, results);
		if (card.onFinish) card.onFinish(results, secs, rejected);
		card.runBtn.textContent = "↻ Retry";
		card.runBtn.disabled = false;
		card.sendBtn.classList.remove("hide");
		card.copyBtn.classList.remove("hide");
		if (card.key) seen.set(card.key, 0); // the AI may repeat the same command after receiving the result
		const needsFeedback = results.some((x) => !x.ok || FEEDBACK_TOOLS.has(x.tool));
		if (state.autoSend && needsFeedback && !card.noAuto) {
			await insertIntoChat(card.resultText, true);
		}
	}

	$("qErr").onclick = () => {
		const c = addCard([{ tool: "get_output", level: "error", limit: 30 }], "fetching latest errors…");
		runCard(c);
	};
	$("qVerify").onclick = () => {
		const c = addCard([{ tool: "verify" }], "auto-auditing the game…");
		runCard(c);
	};
	// Project snapshot: the result is pasted into the chat box (not sent) so you can add more requests
	$("qSnap").onclick = async () => {
		const c = addCard([{ tool: "project_snapshot" }], "taking project snapshot…");
		c.noAuto = true;
		await runCard(c);
		if (c.resultText && (await insertIntoChat(c.resultText, false))) toast("Snapshot pasted — add your request", "ok");
	};
	$("bClear").onclick = () => {
		list.innerHTML = "";
		updateBadges();
		toast("Cards cleared");
	};

	// ---------- tab Tools ----------
	let catFilter = "all";
	function renderTools() {
		const q = $("q").value.trim().toLowerCase();
		const box = $("tlist");
		box.innerHTML = "";
		let n = 0;
		TOOLS.forEach((t) => {
			if (catFilter !== "all" && t.c !== catFilter) return;
			if (q && !(t.n + " " + t.d + " " + CATS[t.c].label).toLowerCase().includes(q)) return;
			n++;
			const c = CATS[t.c];
			const row = el("div", "tl");
			const ic = el("div", "cic", c.icon);
			tagStyle(ic, c.color);
			const mid = el("div");
			mid.append(el("b", "", t.n), el("small", "", t.d));
			const b = el("button", "", "Tanya");
			b.title = t.q;
			b.onclick = async () => {
				if (await insertIntoChat(t.q, false)) toast("Example request pasted", "ok");
			};
			row.append(ic, mid, b);
			box.append(row);
		});
		if (!n) box.append(el("div", "empty", "No matching tools."));
	}
	function renderChips() {
		const box = $("chips");
		box.innerHTML = "";
		const mk = (key, label) => {
			const b = el("button", "chip" + (catFilter === key ? " on" : ""), label);
			b.onclick = () => {
				catFilter = key;
				renderChips();
				renderTools();
			};
			box.append(b);
		};
		mk("all", "All " + TOOLS.length);
		Object.entries(CATS).forEach(([k, c]) => mk(k, c.label + " " + TOOLS.filter((t) => t.c === k).length));
	}
	TEMPLATES.forEach((t) => {
		const b = el("button", "", t.t);
		b.onclick = async () => {
			if (await insertIntoChat(t.p, false)) toast("Template pasted — press send", "ok");
		};
		$("tpl").append(b);
	});
	$("q").addEventListener("input", renderTools);
	renderChips();
	renderTools();

	// ------------------------------------------------------------------
	// AUTO-DEBUG: watch errors from the Studio Output
	// ------------------------------------------------------------------
	let autoDebugCount = 0;
	let lastAutoDebug = 0;

	function addErrorCard(text, count) {
		const wrap = el("div", "card err");
		const ch = el("div", "ch");
		const ic = el("div", "cic", "⚠");
		tagStyle(ic, "#FF5C5C");
		const cti = el("div", "cti");
		const sm = el("small", "", text.split("\n").slice(1, 3).join(" ").slice(0, 120));
		cti.append(el("b", "", `${count} new error(s) in Studio`), sm);
		const x = el("button", "x", "✕");
		x.onclick = (ev) => {
			ev.stopPropagation();
			rmCard(wrap);
		};
		ch.append(ic, cti, x);
		const note = el("div", "note hide", "");
		const cf = el("div", "cf");
		const b = el("button", "btn", "Send to AI");
		b.onclick = async () => {
			if (await insertIntoChat(text, state.autoSend)) {
				note.classList.remove("hide");
				note.textContent = "Sent to chat";
				note.style.color = "var(--ok)";
			}
		};
		cf.append(b);
		wrap.append(ch, note, cf);
		list.prepend(wrap);
		trimList();
		return {
			setStatus: (s, cls) => {
				note.classList.remove("hide");
				note.textContent = s;
				note.style.color = cls === "bad" ? "var(--bad)" : cls === "ok" ? "var(--ok)" : "";
			},
		};
	}

	async function handleErrors(errs) {
		const lines = errs.slice(-10).map((e) => `[${e.source}] ${e.msg}`);
		let text =
			"[RobloxScripter auto error]\n" +
			lines.join("\n---\n") +
			"\nFind the cause (use get_script_source / search_scripts if needed), fix it, then let me know.";
		if (text.length > 4500) text = text.slice(0, 4500) + "\n...(truncated)";
		const card = addErrorCard(text, errs.length);
		if (!state.autoDebug) return;

		const now = Date.now();
		if (now - lastAutoDebug > 90000) autoDebugCount = 0;
		if (busyRuns > 0) {
			card.setStatus("A command is currently running — send manually if needed");
		} else if (autoDebugCount >= 4) {
			card.setStatus("Auto-debug paused (4 in a row) — send manually", "bad");
		} else if (now - lastAutoDebug < 10000) {
			card.setStatus("Too soon after the previous send — send manually if needed");
		} else {
			lastAutoDebug = now;
			autoDebugCount++;
			card.setStatus("Auto-sending to the AI…");
			if (await insertIntoChat(text, true)) card.setStatus("✔ Auto-sent to the AI", "ok");
		}
	}

	async function pollEvents() {
		if (lastSeq === null) return;
		const r = await bg({ type: "events", after: lastSeq });
		if (r.error || typeof r.seq !== "number") return;
		if (r.seq < lastSeq) {
			lastSeq = r.seq; // server was restarted
			return;
		}
		lastSeq = r.seq;
		const errs = (r.events || []).filter((e) => e.level === "error");
		if (errs.length) handleErrors(errs);
	}
	setInterval(pollEvents, 2000);

	// ------------------------------------------------------------------
	// Detect command blocks in AI replies
	// ------------------------------------------------------------------
	// ------------------------------------------------------------------
	// Inline chat renderer: raw JSON / Lua blocks and result messages become animated cards
	// ------------------------------------------------------------------
	const INLINE_CSS = `
	:host{all:initial}
	*{box-sizing:border-box;font-family:ui-monospace,"JetBrains Mono","Cascadia Code",Consolas,monospace}
	.term{background:#0c0d10;border:1px solid #23262f;border-radius:12px;color:#e6e8ef;font-size:13px;line-height:1.4;overflow:hidden;max-width:680px;box-shadow:0 10px 30px rgba(0,0,0,.35);animation:tIn .45s cubic-bezier(.2,.9,.3,1) both}
	.bar{position:relative;display:flex;align-items:center;gap:7px;padding:9px 12px;border-bottom:1px solid #1b1d25;color:#6d7385;font-size:12px}
	.bar i{width:11px;height:11px;border-radius:50%;background:#2a2d38;transition:background .3s}
	.term:hover .bar i:nth-child(1){background:#ff5f57}.term:hover .bar i:nth-child(2){background:#febc2e}.term:hover .bar i:nth-child(3){background:#28c840}
	.bar span{margin-left:auto}
	.bar button{background:none;border:1px solid #2a2d38;color:#6d7385;border-radius:6px;font-size:11px;padding:1px 7px;cursor:pointer;transition:.2s}
	.bar button:hover{color:#e6e8ef;border-color:#4c8dff}
	.term.run .bar::after{content:"";position:absolute;left:0;bottom:-1px;height:2px;width:35%;background:linear-gradient(90deg,transparent,#22d3ee,transparent);animation:sl 1.1s ease-in-out infinite}
	.rows{padding:4px 14px 0}
	.r{display:flex;align-items:baseline;gap:12px;padding:8px 0;border-bottom:1px dashed #20232c;animation:rIn .4s ease both}
	.r:last-child{border-bottom:0}
	.s{width:30px;flex:none;font-weight:700;color:#4b5062}
	.s.ok{color:#3ddc84;animation:pop .4s cubic-bezier(.2,1.6,.4,1)}
	.s.err{color:#ff5c5c;animation:pop .4s cubic-bezier(.2,1.6,.4,1)}
	.s.run::before{content:"\\280B";color:#22d3ee;animation:spin .8s linear infinite}
	.t{color:#22d3ee;font-weight:600;flex:none}
	.h{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
	.d{margin-left:auto;color:#6d7385;font-style:normal;flex:none}
	.foot{display:flex;align-items:center;gap:10px;padding:10px 14px 12px;color:#3ddc84;animation:rIn .4s ease both}
	.foot.run{color:#22d3ee}.foot.bad{color:#ff5c5c}.foot.dim{color:#6d7385}
	.foot button{margin-left:auto;background:#4c8dff;color:#fff;border:0;border-radius:8px;padding:5px 12px;font-weight:700;font-size:12px;cursor:pointer;transition:transform .15s,filter .15s}
	.foot button:hover{filter:brightness(1.15);transform:translateY(-1px)}.foot button:active{transform:scale(.95)}
	.foot button:disabled{opacity:.4;cursor:default}
	.cur{animation:blink 1s steps(1) infinite}
	.shim{background:linear-gradient(90deg,#6d7385 20%,#e6e8ef 50%,#6d7385 80%);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:shim 1.6s linear infinite}
	.pw{display:inline-block;max-width:100%;animation:tIn .4s cubic-bezier(.2,.9,.3,1) both}
	.pill{display:inline-flex;align-items:center;gap:9px;padding:9px 16px;border-radius:12px;background:#15171d;border:1px solid #2a2e3a;color:#d7dae4;font:600 13px system-ui,sans-serif;cursor:pointer;user-select:none;transition:border-color .2s,transform .15s}
	.pill:hover{border-color:#4c8dff;transform:translateY(-1px)}
	.pill .ic{color:#3ddc84}.pill.bad .ic{color:#ff5c5c}
	.pill .chev{color:#8b91a7;font-size:11px;transition:transform .25s}
	.pw.open .chev{transform:rotate(180deg)}
	.pill small{color:#8b91a7;font-weight:500;font-size:12px}
	.body{display:grid;grid-template-rows:0fr;transition:grid-template-rows .3s ease}
	.pw.open .body{grid-template-rows:1fr}
	.body>div{overflow:hidden}
	.body pre{margin:8px 0 0;padding:10px 12px;background:#0c0d10;border:1px solid #23262f;border-radius:10px;color:#b8bdd2;font-size:12px;white-space:pre-wrap;word-break:break-word;max-height:260px;overflow:auto}
	@keyframes tIn{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:none}}
	@keyframes rIn{from{opacity:0;transform:translateX(-10px)}to{opacity:1;transform:none}}
	@keyframes pop{0%{transform:scale(.3);opacity:0}100%{transform:scale(1);opacity:1}}
	@keyframes blink{50%{opacity:0}}
	@keyframes sl{0%{left:-35%}100%{left:100%}}
	@keyframes shim{to{background-position:-200% 0}}
	@keyframes spin{0%{content:"\\280B"}10%{content:"\\2819"}20%{content:"\\2839"}30%{content:"\\2838"}40%{content:"\\283C"}50%{content:"\\2834"}60%{content:"\\2826"}70%{content:"\\2827"}80%{content:"\\2807"}90%{content:"\\280F"}}
	@media (prefers-reduced-motion:reduce){*{animation-duration:.01ms!important;transition-duration:.01ms!important}}
	`;
	const inlineViews = new WeakMap();

	function mkHost(cls) {
		const host = document.createElement("div");
		host.className = "rs-inline-host";
		host.style.cssText = "display:block;margin:10px 0;max-width:100%;";
		const sh = host.attachShadow({ mode: "open" });
		const st = document.createElement("style");
		st.textContent = INLINE_CSS;
		const box = document.createElement("div");
		box.className = cls;
		sh.append(st, box);
		return { host, box };
	}
	function wrapperOf(pre) {
		let cur = pre;
		for (let i = 0; i < 2; i++) {
			const par = cur.parentElement;
			if (!par || par === document.body) break;
			if (par.textContent.trim().length > cur.textContent.trim().length + 60) break;
			cur = par;
		}
		return cur;
	}
	function hintOf(a) {
		try {
			if (a.tree) {
				const t = a.tree;
				const names = [t.name, ...(t.children || []).slice(0, 3).map((c) => c && c.name)].filter(Boolean);
				if (names.length) return names.join(", ");
			}
			if (a.tool === "create_script") return (a.name || "") + (a.script_type ? " · " + a.script_type : "");
			if (a.tool === "set_lighting") return Object.keys(a.effects || {}).join(", ") || "lighting";
		} catch (e) {}
		return argHint(a);
	}

	function makeActionView(pre, hist) {
		const wrap = wrapperOf(pre);
		const { host, box } = mkHost("term");
		const bar = el("div", "bar");
		bar.append(el("i"), el("i"), el("i"), el("span", "", "ai chat + roblox studio"));
		const rawBtn = el("button", "", "{ }");
		rawBtn.title = "Show raw JSON";
		bar.append(rawBtn);
		const rows = el("div", "rows");
		const foot = el("div", "foot");
		box.append(bar, rows, foot);
		wrap.style.display = "none";
		wrap.parentNode.insertBefore(host, wrap);
		const v = { host, box, wrap, rows, foot, cells: [], card: null, raw: false, sig: "", state: "", hist: !!hist, n: 0 };
		rawBtn.onclick = () => {
			v.raw = !v.raw;
			wrap.style.display = v.raw ? "" : "none";
		};
		const sym = { q: ["··", ""], run: ["", "run"], ok: ["ok", "ok"], err: ["err", "err"], hist: ["–", ""] };
		function setCell(i, k, ms) {
			const c = v.cells[i];
			if (!c) return;
			c.s.textContent = sym[k][0];
			c.s.className = "s " + sym[k][1];
			if (ms != null) c.d.textContent = ms < 1000 ? ms + "ms" : (ms / 1000).toFixed(1) + "s";
		}
		function setFoot(cls, html, btn) {
			foot.className = "foot " + cls;
			foot.textContent = "";
			foot.append(...html);
			if (btn) foot.append(btn);
		}
		v.setActions = (actions) => {
			const sig = JSON.stringify(actions.map((a) => [a.tool, hintOf(a)]));
			if (sig === v.sig) return;
			v.sig = sig;
			v.n = actions.length;
			rows.textContent = "";
			v.cells = actions.map((a, i) => {
				const r = el("div", "r");
				r.style.animationDelay = i * 90 + "ms";
				const s = el("b", "s", "");
				const d = el("em", "d", "");
				r.append(s, el("b", "t", a.tool), el("span", "h", hintOf(a)), d);
				rows.append(r);
				return { s, d };
			});
			v.setState(v.card ? v.state : v.hist ? "hist" : "idle");
		};
		v.setState = (st, extra) => {
			v.state = st;
			box.classList.toggle("run", st === "run");
			const all = (k) => v.cells.forEach((_, i) => setCell(i, k));
			if (st === "stream") {
				rows.textContent = "";
				v.cells = [];
				v.sig = "";
				const c = el("span", "cur", "▍");
				setFoot("dim", [c, el("span", "shim", "writing command…")]);
			} else if (st === "hist") {
				all("hist");
				setFoot("dim", [el("span", "", "from chat history · " + v.n + " tool" + (v.n === 1 ? "" : "s"))]);
			} else if (st === "idle") {
				all("q");
				const b = el("button", "", "▶ run");
				b.onclick = () => v.card && !v.card.runBtn.disabled && runCard(v.card);
				setFoot("dim", [el("span", "", "ready · " + v.n + " tool" + (v.n === 1 ? "" : "s"))], v.card ? b : null);
			} else if (st === "run") {
				all("run");
				setFoot("run", [el("span", "shim", extra || "running in Studio…")]);
			} else if (st === "fail") {
				all("err");
				setFoot("bad", [el("span", "", extra || "failed")]);
			}
		};
		v.attach = (card) => {
			v.card = card;
			card.onState = (s) => {
				if (s === "run") v.setState("run");
				else if (s === "bad") v.setState("fail", card.rows.length ? "failed" : "");
				else if (s === "idle") v.setState("idle");
			};
			card.onFinish = (results, secs, rejected) => {
				const n = results.length;
				results.forEach((r, i) => setTimeout(() => setCell(i, r.ok ? "ok" : "err", r.ms), i * 140));
				setTimeout(() => {
					const okc = results.filter((r) => r.ok).length;
					const retry = el("button", "", "↻ retry");
					retry.onclick = () => v.card && !v.card.runBtn.disabled && runCard(v.card);
					if (rejected) setFoot("bad", [el("span", "", "rejected in Studio")], retry);
					else if (okc === n) setFoot("", [el("span", "", "done · " + n + " tool" + (n === 1 ? "" : "s") + " run · " + secs + "s")]);
					else setFoot("bad", [el("span", "", "failed · " + okc + "/" + n + " ok · " + secs + "s")], retry);
					box.classList.remove("run");
				}, n * 140 + 120);
			};
			v.setState(card.state === "run" ? "run" : card.state === "idle" ? "idle" : v.state);
		};
		return v;
	}

	function inlineSync(p, text, hist) {
		const obj = extractJSON(text);
		if (obj && obj._example) return;
		let v = inlineViews.get(p);
		if (v && !v.host.isConnected) {
			const old = v;
			v = makeActionView(p, old.hist);
			v.sig = "";
			inlineViews.set(p, v);
			if (old.card) v.attach(old.card);
		}
		if (!v) {
			v = makeActionView(p, hist);
			inlineViews.set(p, v);
		}
		v.wrap.style.display = v.raw ? "" : "none";
		if (obj && Array.isArray(obj.roblox_scripter)) v.setActions(normalize(obj.roblox_scripter));
		else if (!v.card && !v.hist && v.state !== "stream") v.setState("stream");
	}
	function attachInline(pre, card) {
		const v = pre && inlineViews.get(pre);
		if (v) v.attach(card);
	}

	// Lua code blocks (--@rs:ID) become a compact chip; click to expand the code
	function chipSync(p, text) {
		const m = text.match(MARK);
		if (!m) return;
		let v = inlineViews.get(p);
		const lines = text.slice(m[0].length).split("\n").length;
		if (v && !v.host.isConnected) v = null;
		if (!v) {
			const wrap = wrapperOf(p);
			const { host, box } = mkHost("pw");
			const pill = el("div", "pill");
			const ic = el("span", "ic", "{}");
			const lbl = el("span", "", "");
			const sm = el("small", "", "");
			const chev = el("span", "chev", "▾");
			pill.append(ic, lbl, sm, chev);
			const body = el("div", "body");
			const inner = el("div");
			const pre = el("pre", "", "");
			inner.append(pre);
			body.append(inner);
			box.append(pill, body);
			wrap.style.display = "none";
			wrap.parentNode.insertBefore(host, wrap);
			pill.onclick = () => box.classList.toggle("open");
			v = { host, wrap, lbl, sm, pre, chip: true };
			inlineViews.set(p, v);
		}
		v.wrap.style.display = "none";
		v.lbl.textContent = "Lua code · " + m[1];
		v.sm.textContent = lines + " line" + (lines === 1 ? "" : "s");
		v.pre.textContent = text.slice(m[0].length);
	}

	// Result messages we sent into the chat become a collapsible "result" pill
	const sentResults = [];
	const squash = (s) => String(s).replace(/[^A-Za-z0-9]/g, "");
	const norm = (s) => String(s).replace(/\s+/g, " ").trim();
	function persistSent() {
		try {
			localStorage.setItem("rs_sent", JSON.stringify(sentResults.slice(-12).map((x) => x.text).filter((t) => t.length < 20000)));
		} catch (e) {}
	}
	function registerSent(text) {
		if (!/^\s*\[RobloxScripter /.test(text)) return;
		const n = norm(text);
		if (sentResults.some((x) => x.norm === n)) return;
		const sq = squash(text);
		sentResults.push({ text, norm: n, head: n.slice(0, n.indexOf("]") + 1), sq: sq.length, tail: sq.slice(-30), done: false });
		if (sentResults.length > 40) sentResults.shift();
		persistSent();
	}
	try {
		JSON.parse(localStorage.getItem("rs_sent") || "[]").forEach((t) => {
			const n = norm(t), sq = squash(t);
			sentResults.push({ text: t, norm: n, head: n.slice(0, n.indexOf("]") + 1), sq: sq.length, tail: sq.slice(-30), done: false });
		});
	} catch (e) {}
	function inComposer(node) {
		const e = node.parentElement;
		return !e || !!e.closest('textarea,input,[contenteditable="true"],[contenteditable=""],[contenteditable="plaintext-only"],[role="textbox"]');
	}
	function findBubble(start, x) {
		let cur = start;
		for (let i = 0; i < 8 && cur && cur !== document.body; i++) {
			const t = squash(cur.textContent);
			if (t.length > x.sq + 250) return null;
			if (t.includes(x.tail)) return cur;
			cur = cur.parentElement;
		}
		return null;
	}
	function collapseResult(bub, x) {
		const items = [...x.text.matchAll(/^\d+\.\s+(\S+)\s+(✔|✘)/gm)];
		const bad = items.some((m) => m[2] === "✘") || /error/i.test(x.head);
		const { host, box } = mkHost("pw");
		const pill = el("div", "pill" + (bad ? " bad" : ""));
		let label = "result";
		if (/auto error|error\]/i.test(x.head)) label = "error report";
		else if (items.length) label = items.length === 1 ? items[0][1] + " · result" : items.length + " tools · result";
		pill.append(el("span", "ic", bad ? "✘" : "✓"), el("span", "", label), el("span", "chev", "▾"));
		const body = el("div", "body");
		const inner = el("div");
		inner.append(el("pre", "", x.text));
		body.append(inner);
		box.append(pill, body);
		pill.onclick = () => box.classList.toggle("open");
		bub.style.display = "none";
		bub.parentNode.insertBefore(host, bub);
	}
	function scanResults() {
		const pend = sentResults.filter((x) => !x.done && x.head);
		if (!pend.length || !document.body) return;
		const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
		let n;
		while ((n = w.nextNode())) {
			const v = n.nodeValue;
			if (!v || v.indexOf("[RobloxScripter") < 0) continue;
			const tv = norm(v);
			for (const x of pend) {
				if (x.done || !tv.startsWith(x.head) || inComposer(n)) continue;
				const bub = findBubble(n.parentElement, x);
				if (bub) {
					x.done = true;
					collapseResult(bub, x);
				}
			}
		}
	}
	setInterval(scanResults, 1500);

	const tracked = new WeakMap();
	let baselineUntil = Date.now() + 5000; // ignore chat history that already exists when the page opens
	let lastHref = location.href;
	let urlChangedAt = Date.now();

	function blockText(e) {
		const c = e.querySelector("code");
		return (c ? c.textContent : e.textContent) || "";
	}

	function extractJSON(text) {
		const a = text.indexOf("{"), b = text.lastIndexOf("}");
		if (a < 0 || b <= a) return null;
		try {
			return JSON.parse(text.slice(a, b + 1));
		} catch (e) {
			return null;
		}
	}

	// Lua code marked with --@rs:ID on the first line; the LAST occurrence on the page wins
	const MARK = /^\s*--@rs:([\w-]+)[^\n]*\n?/;
	function codeBlocks() {
		const map = new Map();
		document.querySelectorAll("pre").forEach((p) => {
			const t = blockText(p);
			const m = t.match(MARK);
			if (m) map.set(m[1], t.slice(m[0].length));
		});
		return map;
	}

	function resolveRefs(arr) {
		const blocks = codeBlocks();
		const missing = [];
		const actions = arr.map((a) => {
			const c = Object.assign({}, a);
			for (const base of ["source", "find", "replace", "code"]) {
				const k = base + "_ref";
				if (c[k] == null) continue;
				let code = blocks.get(String(c[k]));
				if (code == null) {
					missing.push(String(c[k]));
				} else {
					if (base === "find" || base === "replace") code = code.replace(/\n$/, "");
					c[base] = code;
				}
				delete c[k];
			}
			return c;
		});
		return { actions, missing };
	}

	async function handle(obj, streamed, pre) {
		if (!obj || obj._example) return null;
		const arr = obj.roblox_scripter;
		if (!Array.isArray(arr) || !arr.length) return null;

		const bad = arr.find((a) => !a || !ALL_TOOLS.has(a.tool));
		if (bad) {
			const c = addCard([{ tool: "project_snapshot" }], "");
			c.runBtn.disabled = true;
			c.setState("bad", "Error");
			c.setNote("Unknown tool: " + (bad && bad.tool), "bad");
			attachInline(pre, c);
			return c;
		}

		let r = resolveRefs(arr);
		for (let i = 0; r.missing.length && i < 12; i++) {
			await sleep(700); // the code block may still be streaming
			r = resolveRefs(arr);
		}
		if (r.missing.length) {
			const c = addCard([{ tool: "project_snapshot" }], "");
			c.runBtn.disabled = true;
			c.setState("bad", "Error");
			c.setNote("Code block not found: " + r.missing.join(", "), "bad");
			c.resultText =
				"[RobloxScripter error] Code block for ref " +
				r.missing.join(", ") +
				" not found. Put the Lua code block BEFORE the JSON block, with the exact same first line --@rs:ID, and the JSON block last.";
			c.sendBtn.classList.remove("hide");
			attachInline(pre, c);
			return c;
		}

		const actions = normalize(r.actions);
		const key = hash(JSON.stringify(actions));
		if (isDup(key)) return null;

		if (state.auto && streamed) {
			const c = addCard(actions, "auto-running…", key);
			attachInline(pre, c);
			runCard(c);
			return c;
		}
		const c2 = addCard(actions, streamed ? "" : "Instant/history block — run manually if needed", key);
		attachInline(pre, c2);
		return c2;
	}

	function scan() {
		const now = Date.now();
		if (location.href !== lastHref) {
			lastHref = location.href;
			urlChangedAt = now;
			baselineUntil = now + 4000; // switched conversation: ignore old blocks
		}
		const baseline = now < baselineUntil;
		document.querySelectorAll("pre").forEach((p) => {
			const text = blockText(p);
			if (!text.includes("roblox_scripter")) {
				if (MARK.test(text)) chipSync(p, text);
				return;
			}
			inlineSync(p, text, baseline);
			let t = tracked.get(p);
			if (!t) {
				t = { text, since: now, streamed: false, done: false };
				tracked.set(p, t);
				if (baseline) {
					t.done = true;
					const o = extractJSON(text);
					if (o && Array.isArray(o.roblox_scripter)) {
						seen.set(hash(JSON.stringify(normalize(resolveRefs(o.roblox_scripter).actions))), Infinity);
					}
					return;
				}
			}
			if (t.done) return;
			if (text !== t.text) {
				t.text = text;
				t.since = now;
				t.streamed = true;
			}
			if (now - t.since < 1200) return; // wait for the text to stop growing
			const obj = extractJSON(text);
			if (!obj) {
				t.streamed = true; // not valid yet, probably still streaming
				return;
			}
			t.done = true;
			handle(obj, t.streamed, p)
				.then((c) => {
					const v = inlineViews.get(p);
					if (!c && v && v.setState) v.setState("hist");
				})
				.catch(() => {});
		});
	}
	setInterval(scan, 700);

	// ------------------------------------------------------------------
	// Auto-paste the prompt in a new chat (paste only; you press send)
	// ------------------------------------------------------------------
	let promptedFor = null;
	function isNewChatUrl() {
		const p = location.pathname;
		return p === "/" || /\/(new|app|chat|home)\/?$/.test(p);
	}
	setInterval(() => {
		if (!state.autoPrompt || promptedFor === location.href) return;
		if (Date.now() - urlChangedAt > 20000) return;
		if (!isNewChatUrl()) return;
		const e = findInput();
		if (!e) return;
		const cur = ((e.value !== undefined ? e.value : e.textContent) || "").trim();
		if (cur || document.querySelector("pre")) return;
		promptedFor = location.href;
		insertIntoChat(PROMPT, false).then((ok) => ok && toast("Prompt auto-pasted", "ok"));
	}, 1800);

	updateBadges();
})();
