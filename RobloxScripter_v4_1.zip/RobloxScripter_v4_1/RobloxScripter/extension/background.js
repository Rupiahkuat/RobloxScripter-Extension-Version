// Service worker: the only part that talks to the local server (free from the AI page's CORS/CSP).
// v3: every request carries the token (X-RS-Token) stored in chrome.storage.
const BASE = "http://127.0.0.1:3030";

async function api(path, opts) {
	const { token } = await chrome.storage.local.get({ token: "" });
	const o = Object.assign({ method: "GET" }, opts || {});
	o.headers = Object.assign({ "Content-Type": "application/json", "X-RS-Token": token || "" }, o.headers || {});
	let r;
	try {
		r = await fetch(BASE + path, o);
	} catch (e) {
		return { error: "server_offline" };
	}
	if (r.status === 401) return { error: "bad_token" };
	try {
		return await r.json();
	} catch (e) {
		return { error: "bad_response" };
	}
}

// Auto-pairing: active only after the user presses "Connect" in the dashboard (60-second window on the server).
async function claim() {
	try {
		const r = await fetch(BASE + "/pair/claim", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
		if (!r.ok) return false;
		const j = await r.json();
		if (j && typeof j.token === "string" && j.token.length >= 24) {
			await chrome.storage.local.set({ token: j.token });
			return true;
		}
	} catch (e) {}
	return false;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
	(async () => {
		if (msg.type === "status") {
			let r = await api("/status");
			if (r.error === "bad_token" && (await claim())) r = await api("/status");
			sendResponse(r);
		} else if (msg.type === "pair") {
			sendResponse({ ok: await claim() });
		} else if (msg.type === "send") {
			sendResponse(await api("/commands", { method: "POST", body: JSON.stringify({ actions: msg.actions }) }));
		} else if (msg.type === "result") {
			sendResponse(await api("/results?id=" + encodeURIComponent(msg.id) + (msg.wait ? "&wait=1" : "")));
		} else if (msg.type === "events") {
			sendResponse(await api("/events?level=error&after=" + encodeURIComponent(msg.after || 0)));
		} else if (msg.type === "select") {
			sendResponse(await api("/select", { method: "POST", body: JSON.stringify({ sid: msg.sid }) }));
		} else {
			sendResponse({ error: "unknown" });
		}
	})();
	return true; // respons async
});
