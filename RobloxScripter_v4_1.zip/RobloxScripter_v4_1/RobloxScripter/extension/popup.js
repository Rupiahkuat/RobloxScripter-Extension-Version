const $ = (id) => document.getElementById(id);

async function status() {
	const r = await chrome.runtime.sendMessage({ type: "status" });
	const set = (d, t, cls, txt) => {
		$(d).className = "dot " + cls;
		$(t).textContent = txt;
	};
	if (!r || r.error === "server_offline") {
		set("d1", "t1", "", "Server: down (run node server.js)");
		set("d2", "t2", "", "Plugin Studio: -");
	} else if (r.error === "bad_token") {
		set("d1", "t1", "y", "Server: running, TOKEN wrong/empty");
		set("d2", "t2", "", "Plugin Studio: -");
	} else {
		set("d1", "t1", "g", "Server: running, token OK");
		const n = (r.plugins || []).length;
		set(
			"d2",
			"t2",
			r.pluginConnected ? "g" : "y",
			r.pluginConnected ? `Studio plugin: connected${n > 1 ? " (" + n + " windows)" : ""}` : "Studio plugin: not connected yet"
		);
	}
}

chrome.storage.local.get({ token: "" }, (v) => {
	if (v.token) $("tok").value = v.token;
});
$("pair").onclick = async () => {
	const r = await chrome.runtime.sendMessage({ type: "pair" });
	if (r && r.ok) {
		const v = await chrome.storage.local.get({ token: "" });
		$("tok").value = v.token;
	} else {
		alert("Pairing is not open. Open the dashboard, then click 'Connect' (60-second window).");
	}
	status();
};
$("dash").onclick = () => chrome.tabs.create({ url: "http://127.0.0.1:3030/" });
$("save").onclick = async () => {
	await chrome.storage.local.set({ token: $("tok").value.trim() });
	status();
};
status();

$("go").onclick = async () => {
	const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
	if (!tab) return;
	try {
		await chrome.tabs.sendMessage(tab.id, { type: "show" });
	} catch (e) {
		try {
			await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
		} catch (err) {
			alert("Cannot be attached to this page: " + err.message);
			return;
		}
	}
	window.close();
};
