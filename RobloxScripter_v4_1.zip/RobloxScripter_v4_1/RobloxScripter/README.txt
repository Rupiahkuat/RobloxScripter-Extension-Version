ROBLOXSCRIPTER v4.1  -  Stage 2.0
=================================
New in 4.1 (on top of v4: same 32 tools, same plugin UI):
  * Local DASHBOARD at http://127.0.0.1:3030/  (server status, Studio sessions, command history with
    durations, tool catalog, EN/ID switch)
  * AUTOMATIC PAIRING: no more copying the token. Click "Connect extension & Studio" in the dashboard;
    for 60 seconds both the browser extension and the Studio plugin fetch the token themselves.
  * Install.bat / Start.bat for Windows (copies the plugin, starts the server, opens the dashboard)
  * Duration timers: per-command total time + plugin run time (dashboard), "· 2.1s" on extension cards,
    "#id done - x.xx s" in the Studio log.
  * Security: pairing only works inside the 60-second window you open yourself; web pages can never
    claim a token (Origin is checked); the dashboard rejects cross-site requests and has a strict CSP.

REQUIREMENTS
  Node.js 16+ (https://nodejs.org). A single .exe that needs no Node comes in Stage 2.1.

FIRST-TIME SETUP (Windows)
  1. Unzip this folder anywhere. Double-click Install.bat.
     - It copies the plugin to %LOCALAPPDATA%\Roblox\Plugins and starts the server.
     - The dashboard opens in your browser.
  2. Chrome/Edge: open chrome://extensions, enable Developer mode, "Load unpacked", pick the "extension" folder.
  3. Restart Roblox Studio. Open Plugins > RobloxScripter and click Allow when Studio asks about HTTP.
  4. In the dashboard click "Connect extension & Studio". Within a minute:
       - the Studio panel shows "Auto-pairing succeeded"
       - the extension panel on an AI site shows "connected to Studio"
     (Manual fallback still works: paste the token from the server console into the extension popup /
      the plugin panel. The popup also has an "Auto pair" button.)

DAILY USE
  Double-click Start.bat (server + dashboard), open Studio's RobloxScripter panel, open your AI site.

UPDATING FROM v4
  - Extension: chrome://extensions > Reload on the RobloxScripter card.
  - Plugin: run Install.bat again (or copy the .lua over the old one) and restart Studio.
  - Server: replace the folder; your token file (server/.rs_token) can be kept or deleted (re-pair).

NOTES
  * Everything in the server, dashboard, pairing logic and extension was tested automatically
    (22 server checks + extension auto-claim + dashboard in Chromium). The Studio plugin changes
    (auto-pair + timers) are small, but could not be run inside real Studio from here: if the panel
    shows an error, copy it and send it back.
  * The tool catalog shown in the dashboard comes from server/tools.json (a copy of the list in the extension).
  * UI texts of the extension/plugin are still Indonesian; the dashboard is English by default.
