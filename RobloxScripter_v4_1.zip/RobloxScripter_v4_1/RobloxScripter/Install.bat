@echo off
setlocal
cd /d "%~dp0"
set "PLUG=%LOCALAPPDATA%\Roblox\Plugins"
if not exist "%PLUG%" mkdir "%PLUG%"
copy /Y "plugin\RobloxScripterBridge.server.lua" "%PLUG%\RobloxScripterBridge.server.lua" >nul
if errorlevel 1 (
  echo [!] Could not copy the plugin to: %PLUG%
  pause
  exit /b 1
)
echo [OK] Plugin installed to: %PLUG%
echo.
echo Next steps:
echo   1. Restart Roblox Studio, then open Plugins ^> RobloxScripter and click Allow if asked.
echo   2. In the dashboard that opens, click "Connect extension ^& Studio".
echo.
call "%~dp0Start.bat"
