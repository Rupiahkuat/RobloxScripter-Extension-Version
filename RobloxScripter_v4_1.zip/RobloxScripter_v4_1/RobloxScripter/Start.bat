@echo off
setlocal
title RobloxScripter Server
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [!] Node.js is not installed. Opening the download page...
  start "" "https://nodejs.org/en/download"
  pause
  exit /b 1
)
echo Starting the RobloxScripter server. The dashboard opens in your browser.
echo Keep this window open while you work. Close it to stop the server.
echo.
node server\server.js --open
echo.
echo The server stopped.
pause
