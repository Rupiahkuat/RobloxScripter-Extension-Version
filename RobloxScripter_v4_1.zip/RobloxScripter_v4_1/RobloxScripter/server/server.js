// RobloxScripter - bridge server v4.1 (no dependencies, Node.js 16+ is enough)
// Run:  node server.js          (new token:  node server.js --new-token)
//
// Commands : Extension --(POST /commands)--> server <--(GET /poll)-- Plugin Studio
// Results  : Plugin --(POST /results)--> server <--(GET /results?wait=1)-- Ekstensi
// Auto-debug: Plugin --(POST /events)--> server <--(GET /events)-- Ekstensi
//
// SECURITY (since v3): every endpoint (except /health) needs the X-RS-Token header. The token is created automatically
// when the server first starts (.rs_token file) and shown in the console. Host header & Origin
// are also checked (anti DNS-rebinding / malicious websites).

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = Number(process.env.PORT) || 3030;
const HOST = "127.0.0.1";
const POLL_HOLD_MS = 10000;
const RESULT_HOLD_MS = 15000;
const TOKEN_FILE = path.join(__dirname, ".rs_token");

function loadToken() {
	if (process.argv.includes("--new-token")) {
		try { fs.unlinkSync(TOKEN_FILE); } catch (e) {}
	}
	try {
		const t = fs.readFileSync(TOKEN_FILE, "utf8").trim();
		if (/^[0-9a-f]{24,}$/.test(t)) return t;
	} catch (e) {}
	const t = crypto.randomBytes(18).toString("hex");
	fs.writeFileSync(TOKEN_FILE, t, { mode: 0o600 });
	return t;
}
const TOKEN = loadToken();
const TOKEN_BUF = Buffer.from(TOKEN);

const DASH_FILE = path.join(__dirname, "dashboard.html");
const TOOLS_FILE = path.join(__dirname, "tools.json");
const LOGO_FILE = path.join(__dirname, "..", "extension", "icons", "icon128.png");
const STARTED = Date.now();
const history = []; // riwayat batch (maks 100): {id,time,tools,ok,total,ms}
const cmdMeta = new Map(); // id -> {t, tools}
let pairUntil = 0; // auto-pairing window (opened from the dashboard)

function tokenOk(given) {
	if (typeof given !== "string") return false;
	const b = Buffer.from(given);
	return b.length === TOKEN_BUF.length && crypto.timingSafeEqual(b, TOKEN_BUF);
}

let nextId = 1;
const plugins = new Map(); // sid -> { sid, name, seen, queue: [], waiter: null }
let activeSid = null;
const pendingQueue = []; // commands that arrive before any plugin is connected
const results = new Map(); // id -> result
const resultWaiters = new Map(); // id -> [{res, timer}]

const events = []; // log Output Studio (error/warning), maks 500
let eventSeq = 0;

function send(res, code, obj) {
	if (res.writableEnded) return;
	res.writeHead(code, { "Content-Type": "application/json" });
	res.end(JSON.stringify(obj));
}

function readJson(req) {
	return new Promise((resolve, reject) => {
		let size = 0;
		const chunks = [];
		req.on("data", (c) => {
			size += c.length;
			if (size > 5 * 1024 * 1024) {
				reject(new Error("body too large"));
				req.destroy();
				return;
			}
			chunks.push(c);
		});
		req.on("end", () => {
			try {
				resolve(JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"));
			} catch (e) {
				reject(e);
			}
		});
		req.on("error", reject);
	});
}

function touchPlugin(sid, name) {
	sid = sid || "default";
	let p = plugins.get(sid);
	if (!p) {
		p = { sid, name: name || "Studio", seen: 0, queue: [], waiter: null };
		plugins.set(sid, p);
		console.log(`[plugin] connected: ${p.name} (${sid.slice(0, 8)})`);
		if (!activeSid || !plugins.has(activeSid)) activeSid = sid;
		if (pendingQueue.length && activeSid === sid) p.queue.push(...pendingQueue.splice(0));
	}
	if (name) p.name = name;
	p.seen = Date.now();
	return p;
}

function pruneAndActive() {
	const now = Date.now();
	for (const [sid, p] of plugins) {
		if (!p.waiter && now - p.seen > 90000) plugins.delete(sid);
	}
	const act = plugins.get(activeSid);
	if (!act || (!act.waiter && now - act.seen > 30000)) {
		let best = null;
		for (const p of plugins.values()) if (!best || p.seen > best.seen) best = p;
		activeSid = best ? best.sid : null;
	}
}

function flush(p) {
	if (p.waiter && p.queue.length) {
		clearTimeout(p.waiter.timer);
		const w = p.waiter;
		p.waiter = null;
		send(w.res, 200, p.queue.shift());
	}
}

function pluginConnected() {
	const now = Date.now();
	for (const p of plugins.values()) if (p.waiter || now - p.seen < 30000) return true;
	return false;
}

function filterLevel(list, level) {
	return level === "all" ? list : list.filter((e) => e.level === level);
}

const ALLOWED_HOSTS = new Set([`127.0.0.1:${PORT}`, `localhost:${PORT}`]);

const server = http.createServer(async (req, res) => {
	// 1) Host must be localhost (anti DNS-rebinding)
	if (!ALLOWED_HOSTS.has(String(req.headers.host || "").toLowerCase())) {
		return send(res, 403, { error: "host rejected" });
	}
	// 2) Origin (if present) must come from the browser extension
	const origin = req.headers.origin;
	// Allowed: the browser extension and this server's own dashboard (other web Origins are rejected)
	const OWN = origin === "http://127.0.0.1:" + PORT || origin === "http://localhost:" + PORT;
	if (origin && !OWN && !origin.startsWith("chrome-extension://") && !origin.startsWith("moz-extension://")) {
		return send(res, 403, { error: "origin rejected" });
	}

	const url = new URL(req.url, `http://${HOST}:${PORT}`);

	// The only endpoint without a token: used to check that the server is alive
	if (req.method === "GET" && url.pathname === "/health") {
		return send(res, 200, { ok: true, v: "4.1" });
	}
	// Dashboard (local web page). The token is embedded in the HTML; other sites cannot read it
	// (same-origin policy + Host/Origin checked + CSP). Cross-site requests are rejected.
	if (req.method === "GET" && url.pathname === "/") {
		if (req.headers["sec-fetch-site"] === "cross-site") return send(res, 403, { error: "rejected" });
		try {
			const html = fs.readFileSync(DASH_FILE, "utf8").replace(/\{\{TOKEN\}\}/g, TOKEN).replace(/\{\{PORT\}\}/g, String(PORT));
			res.writeHead(200, {
				"Content-Type": "text/html; charset=utf-8",
				"Cache-Control": "no-store",
				"X-Frame-Options": "DENY",
				"Content-Security-Policy": "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'",
			});
			return res.end(html);
		} catch (e) {
			return send(res, 500, { error: "dashboard.html not found" });
		}
	}
	if (req.method === "GET" && url.pathname === "/logo.png") {
		try {
			res.writeHead(200, { "Content-Type": "image/png", "Cache-Control": "max-age=3600" });
			return res.end(fs.readFileSync(LOGO_FILE));
		} catch (e) {
			return send(res, 404, { error: "logo not found" });
		}
	}
	// Auto-pairing: only active for 60 seconds after the user presses "Connect" in the dashboard.
	// Regular web Origins are already rejected above; only the extension or the Studio plugin (no Origin) gets through.
	if (req.method === "POST" && url.pathname === "/pair/claim") {
		if (Date.now() > pairUntil) return send(res, 403, { error: "pairing window is not open (click Connect in the dashboard)" });
		console.log("[pair] token given to " + (origin ? "extension" : "plugin/local app"));
		return send(res, 200, { token: TOKEN });
	}

	// 3) Token wajib
	if (!tokenOk(req.headers["x-rs-token"])) {
		return send(res, 401, { error: "wrong or empty token" });
	}

	try {
		if (req.method === "GET" && url.pathname === "/status") {
			pruneAndActive();
			const now = Date.now();
			return send(res, 200, {
				ok: true,
				v: "4.1",
				pluginConnected: pluginConnected(),
				activeSid,
				plugins: [...plugins.values()].map((p) => ({
					sid: p.sid,
					name: p.name,
					active: p.sid === activeSid,
					idle: Math.round((now - p.seen) / 1000),
				})),
				queued: (plugins.get(activeSid) ? plugins.get(activeSid).queue.length : 0) + pendingQueue.length,
				eventSeq,
			});
		}

		if (req.method === "GET" && url.pathname === "/api/state") {
			pruneAndActive();
			const now = Date.now();
			return send(res, 200, {
				v: "4.1",
				uptime: Math.round((now - STARTED) / 1000),
				pluginConnected: pluginConnected(),
				plugins: [...plugins.values()].map((p) => ({ sid: p.sid, name: p.name, active: p.sid === activeSid, idle: Math.round((now - p.seen) / 1000) })),
				pairing: { open: now < pairUntil, secondsLeft: Math.max(0, Math.round((pairUntil - now) / 1000)) },
				history: history.slice(0, 40),
				errors: events.filter((e) => e.level === "error").slice(-5).reverse(),
			});
		}
		if (req.method === "GET" && url.pathname === "/api/tools") {
			return send(res, 200, JSON.parse(fs.readFileSync(TOOLS_FILE, "utf8")));
		}
		if (req.method === "POST" && url.pathname === "/api/pair/open") {
			pairUntil = Date.now() + 60000;
			console.log("[pair] pairing window opened for 60 seconds");
			return send(res, 200, { ok: true, seconds: 60 });
		}

		// choose which Studio receives the command (when there is more than one Studio window)
		if (req.method === "POST" && url.pathname === "/select") {
			const body = await readJson(req);
			if (plugins.has(body.sid)) {
				activeSid = body.sid;
				return send(res, 200, { ok: true, activeSid });
			}
			return send(res, 404, { error: "plugin not found" });
		}

		// Plugin signals it is still alive (during review / long executions)
		if (req.method === "GET" && url.pathname === "/ping") {
			touchPlugin(url.searchParams.get("sid"));
			return send(res, 200, { ok: true });
		}

		if (req.method === "GET" && url.pathname === "/poll") {
			const p = touchPlugin(url.searchParams.get("sid"), url.searchParams.get("name"));
			if (p.waiter) {
				clearTimeout(p.waiter.timer);
				send(p.waiter.res, 200, {});
				p.waiter = null;
			}
			if (p.queue.length) return send(res, 200, p.queue.shift());
			const timer = setTimeout(() => {
				if (p.waiter && p.waiter.res === res) p.waiter = null;
				p.seen = Date.now();
				send(res, 200, {});
			}, POLL_HOLD_MS);
			p.waiter = { res, timer };
			req.on("close", () => {
				if (p.waiter && p.waiter.res === res) {
					clearTimeout(timer);
					p.waiter = null;
				}
			});
			return;
		}

		if (req.method === "POST" && url.pathname === "/commands") {
			const body = await readJson(req);
			if (!Array.isArray(body.actions) || body.actions.length === 0 || body.actions.length > 50) {
				return send(res, 400, { error: "actions must contain 1-50 actions" });
			}
			if (!body.actions.every((a) => a && typeof a === "object" && typeof a.tool === "string")) {
				return send(res, 400, { error: "every action must have a tool field" });
			}
			pruneAndActive();
			const id = nextId++;
			const batch = { id, actions: body.actions };
			cmdMeta.set(id, { t: Date.now(), tools: body.actions.map((a) => a.tool) });
			for (const k of cmdMeta.keys()) if (k < id - 100) cmdMeta.delete(k);
			const p = plugins.get(activeSid);
			if (p) {
				p.queue.push(batch);
				flush(p);
			} else {
				pendingQueue.push(batch);
			}
			console.log(`[#${id}] ${body.actions.length} action(s): ${body.actions.map((a) => a.tool).join(", ")}`);
			return send(res, 200, { id, pluginConnected: pluginConnected() });
		}

		if (req.method === "POST" && url.pathname === "/results") {
			const body = await readJson(req);
			const id = Number(body.id);
			const list = Array.isArray(body.results) ? body.results : [];
			results.set(id, list);
			for (const k of results.keys()) if (k < nextId - 50) results.delete(k);
			const ok = list.filter((r) => r.ok).length;
			const meta = cmdMeta.get(id);
			cmdMeta.delete(id);
			history.unshift({ id, time: Date.now(), tools: meta ? meta.tools : list.map((r) => r.tool), ok, total: list.length, ms: meta ? Date.now() - meta.t : null, execMs: Number.isFinite(Number(body.exec)) ? Math.round(Number(body.exec) * 1000) : null });
			if (history.length > 100) history.pop();
			console.log(`[#${id}] done: ${ok}/${list.length} succeeded`);
			const ws = resultWaiters.get(id);
			if (ws) {
				resultWaiters.delete(id);
				for (const w of ws) {
					clearTimeout(w.timer);
					send(w.res, 200, { done: true, results: list });
				}
			}
			return send(res, 200, { ok: true });
		}

		// Extension: fetch result. ?wait=1 -> long-poll (holds up to 15 s)
		if (req.method === "GET" && url.pathname === "/results") {
			const id = Number(url.searchParams.get("id"));
			if (results.has(id)) return send(res, 200, { done: true, results: results.get(id) });
			if (url.searchParams.get("wait") !== "1") return send(res, 200, { done: false });
			const w = { res };
			w.timer = setTimeout(() => {
				const arr = resultWaiters.get(id) || [];
				resultWaiters.set(id, arr.filter((x) => x !== w));
				send(res, 200, { done: false });
			}, RESULT_HOLD_MS);
			resultWaiters.set(id, [...(resultWaiters.get(id) || []), w]);
			req.on("close", () => clearTimeout(w.timer));
			return;
		}

		// Plugin sends errors/warnings from the Studio Output
		if (req.method === "POST" && url.pathname === "/events") {
			const body = await readJson(req);
			const source = String(body.source || "Studio");
			const now = Date.now();
			let added = 0;
			for (const it of Array.isArray(body.items) ? body.items.slice(0, 50) : []) {
				const level = it.level === "warning" ? "warning" : "error";
				const msg = String(it.msg || "").slice(0, 1500);
				if (!msg) continue;
				const dup = events.slice(-20).some((e) => e.level === level && e.msg === msg && now - e.t < 3000);
				if (dup) continue;
				events.push({ seq: ++eventSeq, t: now, time: new Date(now).toTimeString().slice(0, 8), source, level, msg });
				added++;
				if (level === "error") console.log(`[Studio/${source}] error: ${msg.split("\n")[0].slice(0, 140)}`);
			}
			while (events.length > 500) events.shift();
			return send(res, 200, { ok: true, added });
		}

		// Extension: fetch new errors since a given seq
		if (req.method === "GET" && url.pathname === "/events") {
			const after = Number(url.searchParams.get("after")) || 0;
			const level = url.searchParams.get("level") || "error";
			const fresh = filterLevel(events.filter((e) => e.seq > after), level);
			return send(res, 200, { seq: eventSeq, events: fresh.slice(-30) });
		}

		// Output history (get_output & playtest tools). ?after=seq for only the new ones
		if (req.method === "GET" && url.pathname === "/log") {
			const limit = Math.min(Math.max(Number(url.searchParams.get("limit")) || 30, 1), 100);
			const level = url.searchParams.get("level") || "error";
			const after = Number(url.searchParams.get("after")) || 0;
			return send(res, 200, { events: filterLevel(events.filter((e) => e.seq > after), level).slice(-limit) });
		}

		send(res, 404, { error: "not found" });
	} catch (e) {
		send(res, 400, { error: String(e.message || e) });
	}
});

server.listen(PORT, HOST, () => {
	console.log("==============================================");
	console.log(" RobloxScripter server v4 at http://" + HOST + ":" + PORT);
	console.log("");
	console.log(" YOUR TOKEN (paste into the extension popup & the Studio plugin panel):");
	console.log("   " + TOKEN);
	console.log("");
	console.log(" DASHBOARD: http://" + HOST + ":" + PORT + "/   (click 'Connect' for auto-pairing)");
	console.log(" Manual: paste the token into the extension popup & the Studio plugin panel.");
	console.log(" (new token: node server.js --new-token)");
	console.log("==============================================");
	if (process.argv.includes("--open")) {
		const cmd = process.platform === "win32" ? 'start "" "' : process.platform === "darwin" ? 'open "' : 'xdg-open "';
		require("child_process").exec(cmd + "http://" + HOST + ":" + PORT + '/"');
	}
});
